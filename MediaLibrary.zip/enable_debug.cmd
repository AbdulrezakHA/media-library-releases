@echo off
echo Enabling Adobe CEP PlayerDebugMode for CSXS.11 (Premiere Pro 2022+ / After Effects)
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f
echo.
echo If you are using older versions, you might also need CSXS.10, CSXS.9, etc.
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d "1" /f
echo.
echo Done! Please restart Premiere Pro or After Effects.
pause
