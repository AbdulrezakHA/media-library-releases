@echo off
where node >nul 2>&1
if %errorlevel%==0 (
  echo Starting visual publisher at http://localhost:3415 ...
  echo Keep this window open. Close it to stop the publisher.
  node "%~dp0publisher-server.js"
) else (
  echo Node not found — opening publisher.html directly...
  echo For full save support, install Node.js from https://nodejs.org/
  start "" "%~dp0publisher.html"
)
pause
