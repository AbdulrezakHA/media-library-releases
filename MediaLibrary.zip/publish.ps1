# publish.ps1 - Double-click publish.cmd and answer 2 questions. That's it.
# Handles PRIVATE code repo + PUBLIC updates repo automatically so your source stays private
# but the updater (which needs a public URL) still works. You only ever run publish.cmd.

param([string]$Version, [string[]]$Notes, [switch]$NoPause)
# Ensure GitHub CLI is in PATH (installed at C:\Program Files\GitHub CLI\gh.exe)
if ($env:Path -notlike "*GitHub CLI*") { $env:Path += ";C:\Program Files\GitHub CLI" }
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$configPath = Join-Path $PSScriptRoot ".publish-config.json"
function Load-Config { if (Test-Path $configPath) { try { return Get-Content $configPath -Raw | ConvertFrom-Json } catch {} } ; return $null }
function Save-Config($c) { $c | ConvertTo-Json | Set-Content $configPath -Encoding utf8 }

$config = Load-Config

# --- First-time setup (once) ---
if (-not $config -or -not $config.privateRepo) {
    Write-Host ""
    Write-Host "=== One-time setup (30 seconds) ===" -ForegroundColor Cyan
    Write-Host "We keep your CODE private, and create a tiny PUBLIC repo just for updates." -ForegroundColor Gray
    Write-Host "The public repo only holds update.json + the zip - no browsable source." -ForegroundColor Gray
    Write-Host ""
    $priv = Read-Host "Private repo name - example AbdulrezakHA/media-library"
    if (-not $priv) { throw "Private repo required." }
    $suggestedPublic = $priv + "-releases"
    Write-Host "Public releases repo will be: $suggestedPublic" -ForegroundColor DarkGray
    $pub = Read-Host "Press Enter for $suggestedPublic, or type a different name"
    if ([string]::IsNullOrWhiteSpace($pub)) { $pub = $suggestedPublic }
    $config = [PSCustomObject]@{ privateRepo = $priv.Trim(); publicRepo = $pub.Trim() }
    Save-Config $config
    Write-Host "Saved." -ForegroundColor Green
}

$privateRepo = $config.privateRepo
$publicRepo = $config.publicRepo

# Ensure git remotes
function Ensure-Remote($name, $slug) {
    $url = "https://github.com/$slug.git"
    $existing = $null
    try { $existing = git remote get-url $name 2>&1 } catch {}
    if (-not $existing -or $existing -match "No such remote") { git remote add $name $url; Write-Host "Added remote $name -> $slug" -ForegroundColor Green }
    elseif ($existing -notmatch [regex]::Escape($slug)) { git remote set-url $name $url; Write-Host "Updated remote $name -> $slug" -ForegroundColor Yellow }
}
if (-not (Test-Path ".git")) { git init | Out-Null; Write-Host "Initialized git" -ForegroundColor Green }
Ensure-Remote "origin" $privateRepo
Ensure-Remote "releases" $publicRepo

# Patch updater URL to point to PUBLIC repo (once)
$mainJsPath = Join-Path $PSScriptRoot "js\main.js"
if (Test-Path $mainJsPath) {
    $raw = Get-Content $mainJsPath -Raw
    $newUrl = "https://raw.githubusercontent.com/$publicRepo/main/update.json"
    if ($raw -notmatch [regex]::Escape($newUrl)) {
        $raw -replace "https://raw\.githubusercontent\.com/[^/]+/[^/]+/main/update\.json", $newUrl | Set-Content $mainJsPath -NoNewline
        Write-Host "Updater now points to public releases repo" -ForegroundColor Green
    }
}

# --- Version ---
$currentVersion = "1.0.0"
if (Test-Path "update.json") { try { $currentVersion = (Get-Content "update.json" -Raw | ConvertFrom-Json).version } catch {} }
if (-not $Version) {
    $suggested = "1.0.1"
    Write-Host ""
    Write-Host "Current version: $currentVersion" -ForegroundColor DarkGray
    Write-Host "Press Enter for $suggested, or type 1.1.0" -ForegroundColor Cyan
    $inp = Read-Host "Version [$suggested]"
    $Version = if ([string]::IsNullOrWhiteSpace($inp)) { $suggested } else { $inp.Trim() }
}
if ($Version -notmatch "^\d+\.\d+\.\d+$") { throw "Version must be like 1.0.1" }

# --- Notes / whatsNew (visual publisher) ---
$existingWhatsNew = $null
if (Test-Path "update.json") {
    try {
        $existingJson = Get-Content "update.json" -Raw | ConvertFrom-Json
        if ($existingJson.whatsNew -and $existingJson.whatsNew.pages) { $existingWhatsNew = $existingJson.whatsNew }
    } catch {}
}
# If publisher already created whatsNew pages, keep them and skip cmd prompting
if ($existingWhatsNew -and $existingWhatsNew.pages -and $existingWhatsNew.pages.Count -gt 0) {
    if (-not $Notes -or $Notes.Count -eq 0) {
        $Notes = @()
        foreach ($pg in $existingWhatsNew.pages) { $Notes += $pg.description }
        if ($Notes.Count -eq 0) { $Notes = @("Bug fixes and improvements") }
    }
    $whatsNewToSave = $existingWhatsNew
} else {
    if (-not $Notes -or $Notes.Count -eq 0) {
        Write-Host ""
        Write-Host "What changed? One bullet per line, empty line to finish:" -ForegroundColor Cyan
        Write-Host "  e.g. Added auto-sort for bins" -ForegroundColor DarkGray
        Write-Host "  Tip: Use publisher.html for rich pages with images, videos and buttons instead" -ForegroundColor DarkGray
        $Notes = @()
        while ($true) { $l = Read-Host " -"; if ([string]::IsNullOrWhiteSpace($l)) { break }; $Notes += $l.Trim() }
        if ($Notes.Count -eq 0) { $Notes = @("Bug fixes and improvements") }
    }
    $whatsNewToSave = $null
}

Write-Host ""
Write-Host "Publishing v$Version ..." -ForegroundColor Yellow
Write-Host "  Private: $privateRepo  |  Public: $publicRepo" -ForegroundColor DarkGray
$notesStr = $Notes -join ", "
Write-Host "  Notes: $notesStr" -ForegroundColor DarkGray
if ($whatsNewToSave) { Write-Host "  Pages: $($whatsNewToSave.pages.Count) rich pages with media + buttons" -ForegroundColor Cyan }

# --- Write update.json (goes to PUBLIC repo) ---
$manifestObj = [ordered]@{
    version = $Version; type = "hot"
    message = "Version $Version available!"
    notes   = $Notes
    zipUrl  = "https://github.com/$publicRepo/releases/latest/download/MediaLibrary.zip"
    zxpUrl  = "https://github.com/$publicRepo/releases/latest/download/MediaLibrary.zxp"
}
if ($whatsNewToSave) { $manifestObj.whatsNew = $whatsNewToSave }
$manifestObj | ConvertTo-Json -Depth 5 | Set-Content "update.json" -Encoding utf8

# --- Sync version into source ---
(Get-Content "js\main.js" -Raw) -replace "const CURRENT_VERSION = '[^']+';", "const CURRENT_VERSION = '$Version';" | Set-Content "js\main.js" -NoNewline
$csm = "CSXS\manifest.xml"; $xml = [xml](Get-Content $csm); $xml.ExtensionManifest.ExtensionBundleVersion = $Version
foreach ($ext in $xml.ExtensionManifest.ExtensionList.Extension) { $ext.Version = $Version }
$xml.Save((Resolve-Path $csm).Path)

# --- Zip ---
$staging = Join-Path $env:TEMP "MediaLibraryRelease_$([guid]::NewGuid().ToString('N'))"
New-Item -ItemType Directory -Path $staging | Out-Null
robocopy . "$staging\MediaLibrary" /E /XD node_modules .git .claude whatsnew /XF publish.ps1 publish.cmd publisher.html publisher-server.js publisher.cmd .debug enable_debug.cmd *.zip .publish-config.json > $null
# Copy whatsnew media separately if it exists (bundled in zip so popup works offline, no server needed)
if (Test-Path "whatsnew") { robocopy "whatsnew" "$staging\MediaLibrary\whatsnew" /E > $null }
if ($LASTEXITCODE -ge 8) { throw "robocopy failed $LASTEXITCODE" }
$assetPath = Join-Path $env:TEMP "MediaLibrary.zip"
if (Test-Path $assetPath) { Remove-Item $assetPath -Force }
Compress-Archive -Path "$staging\MediaLibrary\*" -DestinationPath $assetPath -Force
Remove-Item $staging -Recurse -Force
Write-Host "Zipped -> $assetPath" -ForegroundColor Green

# --- Push CODE to private repo ---
$oldPref = $ErrorActionPreference; $ErrorActionPreference = "Continue"
git add update.json js/main.js CSXS/manifest.xml LICENSE 2>&1 | Out-Null
git add . 2>&1 | Out-Null
if (git status --porcelain) { git commit -m "Release v$Version" 2>&1 | Out-Null }
git tag "v$Version" -f 2>&1 | Out-Null
Write-Host "Pushing code to private repo ..." -ForegroundColor Gray
git push origin HEAD --tags 2>&1 | Write-Host
$ErrorActionPreference = $oldPref

# --- Push update.json to PUBLIC repo (tiny repo, just this file) ---
Write-Host "Pushing update.json to public releases repo ..." -ForegroundColor Gray
$tmpPub = Join-Path $env:TEMP "MediaLibraryPub_$([guid]::NewGuid().ToString('N'))"
$oldPref2 = $ErrorActionPreference; $ErrorActionPreference = "Continue"
try {
    git clone --depth 1 "https://github.com/$publicRepo.git" $tmpPub 2>&1 | Out-Null
    if (-not (Test-Path $tmpPub)) {
        # Public repo doesn't exist yet - create it
        Write-Host "Creating public repo $publicRepo ..." -ForegroundColor Yellow
        gh repo create $publicRepo --public --description "Releases for Media Library (auto-managed)" 2>&1 | Write-Host
        Start-Sleep 2
        git clone --depth 1 "https://github.com/$publicRepo.git" $tmpPub 2>&1 | Out-Null
    }
    if (Test-Path $tmpPub) {
        Copy-Item "update.json" (Join-Path $tmpPub "update.json") -Force
        Push-Location $tmpPub
        git add update.json 2>&1 | Out-Null
        if (git status --porcelain) { git commit -m "Update to v$Version" 2>&1 | Out-Null; git push origin HEAD 2>&1 | Write-Host }
        Pop-Location
    }
} catch { Write-Host "Could not push to public repo: $_" -ForegroundColor Yellow }
finally { if (Test-Path $tmpPub) { Remove-Item $tmpPub -Recurse -Force -ErrorAction SilentlyContinue }; $ErrorActionPreference = $oldPref2 }

# --- GitHub Release on PUBLIC repo ---
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Host "Install gh CLI once: https://cli.github.com/  then 'gh auth login'" -ForegroundColor Red
    Write-Host "Zip ready at $assetPath - upload manually to https://github.com/$publicRepo/releases" -ForegroundColor Yellow
    pause; exit 0
}
$notesText = ($Notes | ForEach-Object { "- $_" }) -join "`n"
$oldPref3 = $ErrorActionPreference; $ErrorActionPreference = "Continue"
gh release view "v$Version" --repo $publicRepo 2>&1 | Out-Null
$releaseExists = ($LASTEXITCODE -eq 0)
$ErrorActionPreference = $oldPref3
if ($releaseExists) { gh release upload "v$Version" $assetPath --repo $publicRepo --clobber 2>&1 | Write-Host }
else { gh release create "v$Version" $assetPath --repo $publicRepo --title "v$Version" --notes $notesText 2>&1 | Write-Host }

Write-Host ""
Write-Host "Done! v$Version is live." -ForegroundColor Green
Write-Host "Code -> private ($privateRepo)  |  Updates -> public ($publicRepo)" -ForegroundColor Cyan
Write-Host "Users get banner + Whats New popup on next launch." -ForegroundColor Cyan
Write-Host "https://github.com/$publicRepo/releases/tag/v$Version" -ForegroundColor DarkGray
if (-not $NoPause) { pause }
