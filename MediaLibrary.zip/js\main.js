const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const urlModule = require('url');
const { exec } = require('child_process');
const mm = require('music-metadata');

// Single source of truth for file-type categorization. Keep these in sync
// with the matching lists in jsx/hostscript.jsx (ExtendScript can't share
// this module directly since it runs in a separate JS engine).
const VIDEO_EXTS = ['.mp4', '.mov', '.avi', '.mkv', '.m4v', '.mxf', '.wmv', '.webm', '.r3d', '.braw', '.m2ts', '.mpg'];
const AUDIO_EXTS = ['.wav', '.mp3', '.m4a', '.aac', '.flac', '.ogg', '.aif', '.aiff', '.wma'];
const IMAGE_EXTS = ['.jpg', '.jpeg', '.png', '.gif', '.tif', '.tiff', '.bmp', '.webp', '.psd', '.svg', '.exr', '.dpx', '.psb', '.nef', '.cr2', '.arw', '.heic'];
const SUBTITLE_EXTS = ['.srt', '.vtt', '.stl', '.scc', '.mcc', '.ttml', '.dfxp', '.sbv'];
const PROJECT_EXTS = ['.aep', '.aepx', '.aet', '.prproj', '.ffx', '.mogrt'];
const FONT_EXTS = ['.ttf', '.otf', '.woff', '.woff2'];
const C3D_EXTS = ['.c4d', '.obj', '.fbx'];
const LUT_EXTS = ['.cube', '.3dl', '.look'];
const SCRIPT_EXTS = ['.jsx', '.jsxbin'];
const VECTOR_EXTS = ['.ai', '.eps'];
const DATA_EXTS = ['.json', '.mgjson', '.csv', '.tsv', '.txt', '.xml'];
const PRESET_EXTS = ['.epr', '.sqpreset'];
// Subset of IMAGE_EXTS that Chromium's <img> tag can actually render.
const IMAGE_RENDERABLE_EXTS = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg'];
const SUPPORTED_EXTS = [...VIDEO_EXTS, ...AUDIO_EXTS, ...IMAGE_EXTS, ...SUBTITLE_EXTS, ...PROJECT_EXTS, ...FONT_EXTS, ...C3D_EXTS, ...LUT_EXTS, ...SCRIPT_EXTS, ...VECTOR_EXTS, ...DATA_EXTS, ...PRESET_EXTS];

function getAssetKind(ext) {
    if (VIDEO_EXTS.includes(ext)) return 'video';
    if (AUDIO_EXTS.includes(ext)) return 'audio';
    if (IMAGE_EXTS.includes(ext)) return 'image';
    if (SUBTITLE_EXTS.includes(ext)) return 'subtitle';
    if (PROJECT_EXTS.includes(ext)) return 'project';
    if (FONT_EXTS.includes(ext)) return 'font';
    if (C3D_EXTS.includes(ext)) return 'c3d';
    if (LUT_EXTS.includes(ext)) return 'lut';
    if (SCRIPT_EXTS.includes(ext)) return 'script';
    if (VECTOR_EXTS.includes(ext)) return 'vector';
    if (DATA_EXTS.includes(ext)) return 'data';
    if (PRESET_EXTS.includes(ext)) return 'preset';
    return null;
}
function getAssetIcon(kind) {
    const icons = { video: '🎬', audio: '🎵', image: '🖼️', subtitle: '💬', project: '📦', font: '🔤', c3d: '🧊', lut: '🎨', script: '📜', vector: '✒️', data: '💾', preset: '🎛️' };
    return icons[kind] || '📄';
}

function capitalize(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
}

// --- Update system (GitHub-hosted manifest) ---
// The manifest is a plain update.json committed to the repo root; releases
// attach MediaLibrary.zip (whole extension folder) as an asset. The
// "releases/latest/download/..." URL always points at the newest release,
// so the manifest never needs its download links rewritten.
const UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/AbdulrezakHA/media-library-releases/main/update.json';

// Positive if b is newer than a. Compares dot-separated numeric segments so
// "1.10.0" > "1.9.0" (a plain string !== check would misjudge both format
// drift and multi-digit segments).
function compareVersions(a, b) {
    const pa = String(a).split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const d = (pa[i] || 0) - (pb[i] || 0);
        if (d !== 0) return d;
    }
    return 0;
}

// HTTP(S) GET with redirect following - needed because GitHub release asset
// URLs respond with 302s to their S3 backing store.
function httpGet(url, cb, redirectsLeft) {
    const max = (redirectsLeft === undefined) ? 5 : redirectsLeft;
    const mod = url.indexOf('https://') === 0 ? https : http;
    const req = mod.get(url, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && max > 0) {
            res.resume();
            httpGet(urlModule.resolve(url, res.headers.location), cb, max - 1);
            return;
        }
        if (res.statusCode !== 200) {
            res.resume();
            cb(new Error('HTTP ' + res.statusCode + ' for ' + url));
            return;
        }
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => cb(null, Buffer.concat(chunks)));
    });
    req.on('error', cb);
}

function fetchUpdateManifest() {
    return new Promise((resolve, reject) => {
        const url = UPDATE_MANIFEST_URL + (UPDATE_MANIFEST_URL.indexOf('?') === -1 ? '?' : '&') + 't=' + Date.now();
        httpGet(url, (err, data) => {
            if (err) { reject(err); return; }
            try {
                let txt = data.toString('utf8').replace(/^\uFEFF/, '').trim();
                if (!txt) throw new Error('Empty response');
                resolve(JSON.parse(txt));
            }
            catch (e) { reject(e); }
        });
    });
}

function psQuote(s) { return "'" + s.replace(/'/g, "''") + "'"; }

function runCommand(cmd) {
    return new Promise((resolve, reject) => {
        exec(cmd, { windowsHide: true }, (err) => err ? reject(err) : resolve());
    });
}

function copyRecursive(src, dest) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    const entries = fs.readdirSync(src, { withFileTypes: true });
    for (const entry of entries) {
        const s = path.join(src, entry.name);
        const d = path.join(dest, entry.name);
        if (entry.isDirectory()) copyRecursive(s, d);
        else fs.copyFileSync(s, d);
    }
}

// Downloads the release zip and extracts it over the live extension folder.
// Safe to overwrite our own files mid-run: Chromium and ExtendScript read
// them into memory without keeping locks, and location.reload() picks up
// the new code afterwards. Requires the unsigned/debug-mode install this
// plugin already ships with (a signed ZXP would fail validation once its
// files change on disk).
async function applyHotUpdate(zipUrl) {
    const tmpZip = path.join(os.tmpdir(), 'MediaLibraryUpdate.zip');
    const tmpDir = path.join(os.tmpdir(), 'MediaLibraryUpdate_' + Date.now());

    const data = await new Promise((res, rej) => httpGet(zipUrl, (e, d) => e ? rej(e) : res(d)));
    fs.writeFileSync(tmpZip, data);
    fs.mkdirSync(tmpDir, { recursive: true });

    // Expand-Archive via PowerShell - avoids bundling a zip dependency
    await runCommand('powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath ' +
        psQuote(tmpZip) + ' -DestinationPath ' + psQuote(tmpDir) + ' -Force"');

    // Locate the extracted root - tolerate either index.html at zip top
    // level or inside a single wrapper folder
    let srcRoot = null;
    if (fs.existsSync(path.join(tmpDir, 'index.html'))) {
        srcRoot = tmpDir;
    } else {
        const subs = fs.readdirSync(tmpDir, { withFileTypes: true }).filter(d => d.isDirectory());
        for (const sub of subs) {
            if (fs.existsSync(path.join(tmpDir, sub.name, 'index.html'))) {
                srcRoot = path.join(tmpDir, sub.name);
                break;
            }
        }
    }
    if (!srcRoot) throw new Error('Downloaded update zip did not contain index.html');

    const extPath = window.__adobe_cep__.getSystemPath('extension');
    copyRecursive(srcRoot, extPath);

    try { fs.unlinkSync(tmpZip); } catch (e) {}
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (e) {}
}
const DATA_PATH = path.join(os.homedir(), 'AppData', 'Roaming', 'Adobe', 'CEP', 'MediaLibraryData.json');
const WAVEFORM_DIR = path.join(os.homedir(), 'AppData', 'Roaming', 'Adobe', 'CEP', 'MediaLibraryWaveforms');

function isJunkFile(name) {
    if (name.startsWith('.')) return true; // hidden files, AppleDouble (._)
    if (name.toLowerCase() === 'thumbs.db') return true;
    // Ignore thumbnail images for audio/video files
    const lower = name.toLowerCase();
    if (lower.endsWith('.wav.png') || lower.endsWith('.mp3.png') || lower.endsWith('.m4a.png') || lower.endsWith('.mp4.png') || 
        lower.endsWith('.wav.jpg') || lower.endsWith('.mp3.jpg') || lower.endsWith('.m4a.jpg') || lower.endsWith('.mp4.jpg')) {
        return true;
    }
    return false;
}

if (!fs.existsSync(WAVEFORM_DIR)) {
    fs.mkdirSync(WAVEFORM_DIR, { recursive: true });
}
const CURRENT_VERSION = '2.0.0';
let PORTFOLIO_URL = 'https://abdulrezak.com'; // Support the creator
let appData = { folders: [], categories: {}, folderCache: {} };
let currentAssets = []; 
let currentFilteredAssets = [];
let renderedCount = 0;
const CHUNK_SIZE = 50;
let activeFilters = { audio: true, video: true, image: true, project: true, font: true, c3d: true, lut: true, script: true, vector: true, data: true, preset: true, subtitle: true };
let currentWatchedDir = null;
let folderWatcher = null;
let watchDebounceTimer = null;

// Audio Context for Waveforms (Lazy loaded)
let audioCtx = null;
function getAudioCtx() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    return audioCtx;
}

// Generic modal, used instead of native confirm()/alert() so dialogs match
// the panel's own theme.
// - Default mode (no options.choices): Promise<boolean>, true if confirmed.
// - Choice mode (options.choices = [{label, value}, ...]): renders one
//   button per choice instead of a single confirm button; resolves to the
//   selected choice's `value`, or null if cancelled.
function showModal(message, options = {}) {
    const overlay = document.getElementById('modal-overlay');
    const titleEl = document.getElementById('modal-title');
    const msgEl = document.getElementById('modal-message');
    const cancelBtn = document.getElementById('modal-cancel-btn');
    const confirmBtn = document.getElementById('modal-confirm-btn');
    const actionsEl = confirmBtn.parentElement;

    titleEl.textContent = options.title || '';
    titleEl.style.display = options.title ? 'block' : 'none';
    msgEl.textContent = message;
    cancelBtn.style.display = options.showCancel === false ? 'none' : 'inline-block';
    overlay.classList.remove('hidden');

    // Clear any choice buttons left over from a previous call.
    actionsEl.querySelectorAll('.modal-choice-btn').forEach(b => b.remove());

    return new Promise((resolve) => {
        const choiceBtns = [];
        function cleanup(result) {
            overlay.classList.add('hidden');
            confirmBtn.style.display = '';
            confirmBtn.removeEventListener('click', onConfirm);
            cancelBtn.removeEventListener('click', onCancel);
            choiceBtns.forEach(b => b.remove());
            resolve(result);
        }
        function onConfirm() { cleanup(true); }
        function onCancel() { cleanup(options.choices ? null : false); }
        cancelBtn.addEventListener('click', onCancel);

        if (options.choices) {
            confirmBtn.style.display = 'none';
            options.choices.forEach((choice) => {
                const btn = document.createElement('button');
                btn.className = 'modal-btn primary modal-choice-btn';
                btn.textContent = choice.label;
                btn.addEventListener('click', () => cleanup(choice.value));
                actionsEl.insertBefore(btn, cancelBtn);
                choiceBtns.push(btn);
            });
        } else {
            confirmBtn.textContent = options.confirmText || 'OK';
            confirmBtn.addEventListener('click', onConfirm);
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    loadData();

    // Host app detection (PPRO vs AEFT) - used to adapt the UI, since drag-
    // and-drop into the timeline only works in Premiere (see createAssetItem).
    let isAE = false;
    if (window.__adobe_cep__) {
        try {
            const hostEnv = JSON.parse(window.__adobe_cep__.getHostEnvironment());
            isAE = hostEnv.appName === 'AEFT';
        } catch (e) {}
    }

    // UI Elements
    const addFolderBtn = document.getElementById('add-folder-btn');
    const addCategoryBtn = document.getElementById('add-category-btn');
    const folderList = document.getElementById('folder-list');
    const categoryList = document.getElementById('category-list');
    const assetGrid = document.getElementById('asset-grid');
    const currentPathDisplay = document.getElementById('current-path-display');
    const loadingIndicator = document.getElementById('loading-indicator');
    const searchInput = document.getElementById('search-input');
    const sortSelect = document.getElementById('sort-select');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const newWindowBtn = document.getElementById('new-window-btn');
    const organizeProjectBtn = document.getElementById('organize-project-btn');
    const restoreOfflineBtn = document.getElementById('restore-offline-btn');

    // Update UI
    const updateBanner = document.getElementById('update-banner');
    const updateMessage = document.getElementById('update-message');
    const updateActionBtn = document.getElementById('update-action-btn');
    const updateCloseBtn = document.getElementById('update-close-btn');

    // Events
    addFolderBtn.addEventListener('click', handleAddFolder);
    addCategoryBtn.addEventListener('click', handleAddCategory);
    searchInput.addEventListener('input', renderGrid);
    sortSelect.addEventListener('change', renderGrid);

    if (organizeProjectBtn) {
        organizeProjectBtn.addEventListener('click', async () => {
            if (!window.__adobe_cep__) return;

            const unitPlural = isAE ? 'comps' : 'sequences';
            const unitSingular = isAE ? 'comp' : 'sequence';
            const nestLabel = isAE ? 'Nested Comps' : 'Nests';
            const flatCategories = isAE
                ? 'Video Library, SFX Library, Music Library, Images Library, Solids, Comps, ' +
                  nestLabel + ', Subtitles, Offline, Unused'
                : 'Video Library, SFX Library, Music Library, Images Library, Solids, Sequences, ' +
                  'Nests, Motion Graphics Templates, Linked Comps';
            const offlineNote = ' with their original folder remembered so Restore Offline ' +
                'Files can put them back once relinked';

            const mode = await showModal(
                'Flat: files everything into top-level library bins (' + flatCategories + '). ' +
                'Video, audio, and image files you\'ve already filed into your own folders ' +
                '(e.g. by camera) are left alone; files sitting in one of this plugin\'s own ' +
                'folders - even from a prior Per-' + capitalize(unitSingular) + ' run - are ' +
                're-examined and re-filed as needed.\n\n' +
                'Per-' + capitalize(unitSingular) + ': gives each ' + unitSingular + ' its own ' +
                'folder with those same library bins inside, for files used only by that ' +
                unitSingular + '. Files used by multiple ' + unitPlural + ' go into a shared ' +
                '"Shared Files" folder instead of being duplicated. This reorganizes ' +
                'everything, including files already filed manually, since it regroups by a ' +
                'different axis (which ' + unitSingular + ' uses it).\n\n' +
                'Both modes: offline files always go into Offline regardless of location' + offlineNote + '.',
                {
                    title: 'Organize Project',
                    choices: [
                        { label: 'Flat', value: 'flat' },
                        { label: 'Per-' + capitalize(unitSingular), value: 'sequence' }
                    ]
                }
            );
            if (!mode) return;

            const script = mode === 'sequence' ? '$._ext.organizeProjectBySequence()' : '$._ext.organizeProject()';

            organizeProjectBtn.disabled = true;
            organizeProjectBtn.innerText = 'Organizing...';
            window.__adobe_cep__.evalScript(script, (result) => {
                organizeProjectBtn.disabled = false;
                organizeProjectBtn.innerText = 'Organize Project';
                showModal(result, { title: 'Organize Project', showCancel: false });
            });
        });
    }

    if (restoreOfflineBtn) {
        restoreOfflineBtn.addEventListener('click', async () => {
            if (!window.__adobe_cep__) return;
            const proceed = await showModal(
                'This looks at everything in the Offline folder. Anything that\'s no ' +
                'longer offline (i.e. you relinked it) gets moved back to the folder it ' +
                'came from. Files still offline are left alone.',
                { title: 'Restore Offline Files', confirmText: 'Restore' }
            );
            if (!proceed) return;

            restoreOfflineBtn.disabled = true;
            restoreOfflineBtn.innerText = 'Restoring...';
            window.__adobe_cep__.evalScript('$._ext.restoreOfflineFiles()', (result) => {
                restoreOfflineBtn.disabled = false;
                restoreOfflineBtn.innerText = 'Restore Offline Files';
                showModal(result, { title: 'Restore Offline Files', showCancel: false });
            });
        });
    }

    // Load saved filters (merge with defaults so new kinds default to true)
    const savedFilters = localStorage.getItem('activeFilters');
    if (savedFilters) {
        try {
            const parsed = JSON.parse(savedFilters);
            for (const k in parsed) { if (parsed.hasOwnProperty(k)) activeFilters[k] = parsed[k]; }
        } catch(e) {}
    }

    // Filter Buttons
    filterBtns.forEach(btn => {
        const type = btn.dataset.type;
        btn.classList.toggle('active', activeFilters[type]);
        
        btn.addEventListener('click', (e) => {
            activeFilters[type] = !activeFilters[type];
            e.target.classList.toggle('active', activeFilters[type]);
            localStorage.setItem('activeFilters', JSON.stringify(activeFilters));
            renderGrid();
        });
    });

    // Multi-Window Support
    if (window.__adobe_cep__) {
        const extId = window.__adobe_cep__.getExtensionId();
        if (extId === 'com.custom.medialibrary.panel3') {
            if (newWindowBtn) newWindowBtn.style.display = 'none';
        } else {
            if (newWindowBtn) {
                newWindowBtn.addEventListener('click', () => {
                    if (extId === 'com.custom.medialibrary.panel') {
                        window.__adobe_cep__.requestOpenExtension('com.custom.medialibrary.panel2', '');
                    } else if (extId === 'com.custom.medialibrary.panel2') {
                        window.__adobe_cep__.requestOpenExtension('com.custom.medialibrary.panel3', '');
                    }
                });
            }
        }
    }

    // --- Update Checker Logic ---
    if (updateCloseBtn) {
        updateCloseBtn.addEventListener('click', () => updateBanner.classList.add('hidden'));
    }

    // --- Whats New helpers (Adobe-style multi-page) ---
    function resolveWhatsNewMedia(mediaPath) {
        if (!mediaPath) return null;
        if (mediaPath.indexOf('http://') === 0 || mediaPath.indexOf('https://') === 0 || mediaPath.indexOf('file://') === 0 || mediaPath.indexOf('data:') === 0) return mediaPath;
        try {
            if (window.__adobe_cep__) {
                const extPath = window.__adobe_cep__.getSystemPath('extension');
                if (extPath) {
                    const full = path.join(extPath, mediaPath);
                    return 'file:///' + full.replace(/\\/g, '/');
                }
            }
        } catch (e) {}
        return mediaPath;
    }

    function showWhatsNewCarousel(pages, version) {
        const overlay = document.getElementById('whatsnew-overlay');
        const navList = document.getElementById('whatsnew-nav-list');
        const titleEl = document.getElementById('whatsnew-page-title');
        const descEl = document.getElementById('whatsnew-page-desc');
        const mediaEl = document.getElementById('whatsnew-media');
        const dotsEl = document.getElementById('whatsnew-dots');
        const btnsEl = document.getElementById('whatsnew-page-buttons');
        const verEl = document.getElementById('whatsnew-version-title');
        const prevBtn = document.getElementById('whatsnew-prev');
        const nextBtn = document.getElementById('whatsnew-next');
        const closeBtn = document.getElementById('whatsnew-close');
        if (!overlay || !navList) return;

        if (verEl) verEl.textContent = 'Media Library v' + version;
        let current = 0;

        function render() {
            navList.innerHTML = '';
            dotsEl.innerHTML = '';
            pages.forEach((p, i) => {
                const li = document.createElement('li');
                li.className = 'whatsnew-nav-item' + (i === current ? ' active' : '');
                li.textContent = p.title || ('Feature ' + (i + 1));
                li.addEventListener('click', () => { current = i; render(); });
                navList.appendChild(li);

                const dot = document.createElement('div');
                dot.className = 'whatsnew-dot' + (i === current ? ' active' : '');
                dot.addEventListener('click', () => { current = i; render(); });
                dotsEl.appendChild(dot);
            });

            const page = pages[current];
            titleEl.textContent = page.title || '';
            descEl.textContent = page.description || '';

            // Media (image or video) - bundled in zip, no server needed
            mediaEl.innerHTML = '';
            if (page.media) {
                const url = resolveWhatsNewMedia(page.media);
                const isVideo = /\.(mp4|webm|mov)$/i.test(page.media) || page.mediaType === 'video';
                if (isVideo) {
                    const v = document.createElement('video');
                    v.src = url;
                    v.autoplay = true; v.loop = true; v.muted = true; v.playsInline = true;
                    v.controls = false;
                    mediaEl.appendChild(v);
                    v.play().catch(() => {});
                } else {
                    const img = document.createElement('img');
                    img.src = url;
                    img.onerror = () => { mediaEl.innerHTML = '<div class="media-placeholder">🖼️</div>'; };
                    mediaEl.appendChild(img);
                }
            } else {
                mediaEl.innerHTML = '<div class="media-placeholder">✨</div>';
            }

            // Buttons with links
            btnsEl.innerHTML = '';
            (page.buttons || []).forEach(b => {
                const btn = document.createElement('button');
                btn.className = 'modal-btn ' + (b.primary ? 'primary' : 'secondary');
                btn.textContent = b.label || 'Learn more';
                btn.addEventListener('click', () => {
                    const url = b.url;
                    if (!url) return;
                    try {
                        if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) window.cep.util.openURLInDefaultBrowser(url);
                        else if (window.__adobe_cep__ && window.cep) window.cep.util.openURLInDefaultBrowser(url);
                        else window.open(url, '_blank');
                    } catch (e) { window.open(url, '_blank'); }
                });
                btnsEl.appendChild(btn);
            });

            prevBtn.style.visibility = current === 0 ? 'hidden' : 'visible';
            nextBtn.textContent = current === pages.length - 1 ? 'Done' : 'Next';
        }

        prevBtn.onclick = () => { if (current > 0) { current--; render(); } };
        nextBtn.onclick = () => {
            if (current < pages.length - 1) { current++; render(); }
            else overlay.classList.add('hidden');
        };
        closeBtn.onclick = () => overlay.classList.add('hidden');
        overlay.onclick = (e) => { if (e.target === overlay) overlay.classList.add('hidden'); };

        render();
        overlay.classList.remove('hidden');
    }

    // "What's New" popup, shown once after an update lands. Supports both
    // old single-text notes and new multi-page carousel with media + buttons.
    function showWhatsNewIfPending() {
        try {
            let pending = null;
            const raw = localStorage.getItem('whatsNew');
            if (raw) {
                pending = JSON.parse(raw);
                localStorage.removeItem('whatsNew');
            }
            if (localStorage.getItem('lastSeenVersion') !== CURRENT_VERSION) {
                localStorage.setItem('lastSeenVersion', CURRENT_VERSION);
            }
            if (!pending) return;
            // New carousel format
            if (pending.whatsNew && Array.isArray(pending.whatsNew.pages) && pending.whatsNew.pages.length > 0) {
                showWhatsNewCarousel(pending.whatsNew.pages, pending.version);
                return;
            }
            // Back-compat: old notes array -> single carousel page
            if (Array.isArray(pending.notes) && pending.notes.length > 0) {
                const pages = pending.notes.map((n, i) => ({
                    title: i === 0 ? "What's New" : 'Feature ' + (i + 1),
                    description: n,
                    media: null,
                    buttons: []
                }));
                // If single note, show as one page; else multi-page
                if (pages.length === 1) pages[0].title = "What's New in v" + pending.version;
                showWhatsNewCarousel(pages, pending.version);
                return;
            }
            // Fallback: legacy plain modal
            if (pending.whatsNew && pending.whatsNew.pages) {
                showWhatsNewCarousel(pending.whatsNew.pages, pending.version);
            }
        } catch (e) { console.error(e); }
    }
    showWhatsNewIfPending();

    if (window.__adobe_cep__) {
        fetchUpdateManifest().then(updateInfo => {
            if (!updateInfo || !updateInfo.version) return;
            lastUpdateInfo = updateInfo;
            // Sync portfolio/welcome from publisher's About (even if no update)
            if (updateInfo.about) {
                if (updateInfo.about.portfolioUrl) PORTFOLIO_URL = updateInfo.about.portfolioUrl;
                if (updateInfo.about.welcomeText) { const d = document.getElementById('welcome-desc'); if (d) d.textContent = updateInfo.about.welcomeText; }
            }
            if (compareVersions(CURRENT_VERSION, updateInfo.version) >= 0) return;

            if (updateMessage) updateMessage.innerText = updateInfo.message || ('Version ' + updateInfo.version + ' available!');
            if (updateBanner) updateBanner.classList.remove('hidden');

            // Stash whatsNew (new carousel) or fallback notes, so popup shows after reload
            const pendingPayload = JSON.stringify({
                version: updateInfo.version,
                notes: updateInfo.notes || [],
                whatsNew: updateInfo.whatsNew || null
            });

            if (!updateActionBtn) return;

            if (updateInfo.type === 'zxp') {
                updateActionBtn.innerText = 'Download Update';
                updateActionBtn.onclick = () => {
                    localStorage.setItem('whatsNew', pendingPayload);
                    window.cep.util.openURLInDefaultBrowser(updateInfo.zxpUrl);
                };
            } else {
                updateActionBtn.innerText = 'Install Now';
                updateActionBtn.onclick = async () => {
                    updateActionBtn.disabled = true;
                    updateActionBtn.innerText = 'Downloading...';
                    try {
                        await applyHotUpdate(updateInfo.zipUrl);
                        localStorage.setItem('whatsNew', pendingPayload);
                        updateActionBtn.innerText = 'Restarting...';
                        setTimeout(() => location.reload(), 400);
                    } catch (e) {
                        console.error('Update failed:', e);
                        showModal('Update failed: ' + e.message + '. You can download the latest version manually from the releases page.', {
                            title: 'Update Failed',
                            showCancel: false
                        });
                        updateActionBtn.disabled = false;
                        updateActionBtn.innerText = 'Install Now';
                    }
                };
                if (updateBanner) updateBanner.classList.add('hot-update');
            }
        }).catch(e => console.error('Update check failed:', e));
    }

    // --- Version indicator + Welcome / About / Whats New ---
    const versionIndicator = document.getElementById('version-indicator');
    const welcomeVersion = document.getElementById('welcome-version');
    if (versionIndicator) versionIndicator.textContent = 'v' + CURRENT_VERSION;
    if (welcomeVersion) welcomeVersion.textContent = 'v' + CURRENT_VERSION;
    // Double-click version to open DevTools (Ctrl+Shift+J doesn't work in CEP)
    if (versionIndicator && window.__adobe_cep__) {
        versionIndicator.title = 'Double-click to open DevTools';
        versionIndicator.style.cursor = 'pointer';
        versionIndicator.addEventListener('dblclick', () => {
            try { window.__adobe_cep__.showDevTools(); } catch (e) {}
            try { window.cep.util.openURLInDefaultBrowser('http://localhost:8088'); } catch (e) {}
        });
    }
    const welcomeOverlay = document.getElementById('welcome-overlay');
    const whatsNewBtn = document.getElementById('whatsnew-btn');
    const aboutBtn = document.getElementById('about-btn');
    const portfolioLink = document.getElementById('portfolio-link');
    const portfolioBtn = document.getElementById('portfolio-btn');
    const welcomeWhatsNewBtn = document.getElementById('welcome-whatsnew-btn');
    const welcomeClose = document.getElementById('welcome-close');

    function openPortfolio() {
        const url = PORTFOLIO_URL;
        try {
            if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) window.cep.util.openURLInDefaultBrowser(url);
            else if (window.__adobe_cep__) window.cep.util.openURLInDefaultBrowser(url);
            else window.open(url, '_blank');
        } catch (e) { window.open(url, '_blank'); }
    }
    function showWelcome() { if (welcomeOverlay) welcomeOverlay.classList.remove('hidden'); }
    function hideWelcome() { if (welcomeOverlay) welcomeOverlay.classList.add('hidden'); try { localStorage.setItem('hasSeenWelcome', 'true'); } catch (e) {} }

    if (portfolioLink) portfolioLink.addEventListener('click', openPortfolio);
    if (portfolioBtn) portfolioBtn.addEventListener('click', openPortfolio);
    if (aboutBtn) aboutBtn.addEventListener('click', showWelcome);
    if (welcomeClose) welcomeClose.addEventListener('click', hideWelcome);
    if (welcomeOverlay) welcomeOverlay.addEventListener('click', (e) => { if (e.target === welcomeOverlay) hideWelcome(); });
    if (welcomeWhatsNewBtn) welcomeWhatsNewBtn.addEventListener('click', () => { hideWelcome(); setTimeout(() => showWhatsNewManually(), 200); });

    let lastUpdateInfo = null;
    function loadLocalUpdateJson() {
        const tryRead = (p) => {
            try {
                if (fs.existsSync(p)) {
                    let txt = fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '').trim();
                    if (!txt) return null;
                    // Handle if file was saved with BOM as bytes still present
                    if (txt.charCodeAt(0) === 0xFEFF) txt = txt.slice(1);
                    return JSON.parse(txt);
                }
            } catch (e) { console.error('tryRead fs failed for', p, e.message); }
            // Try cep.fs as fallback
            try {
                if (window.cep && window.cep.fs && window.cep.fs.readFile) {
                    const r = window.cep.fs.readFile(p);
                    if (r.err === 0 && r.data) {
                        let txt2 = r.data.replace(/^\uFEFF/, '').trim();
                        if (!txt2) return null;
                        return JSON.parse(txt2);
                    }
                }
            } catch (e) {}
            return null;
        };
        try {
            if (window.__adobe_cep__) {
                const extPath = window.__adobe_cep__.getSystemPath('extension');
                const r = tryRead(path.join(extPath, 'update.json'));
                if (r) return r;
            }
            const relPaths = ['update.json', './update.json', '../update.json'];
            for (const rp of relPaths) {
                const r = tryRead(rp);
                if (r) return r;
            }
            try { const cwd = process.cwd(); const r = tryRead(path.join(cwd, 'update.json')); if (r) return r; } catch (e) {}
            // Last resort: use last fetched info
            if (lastUpdateInfo) return lastUpdateInfo;
        } catch (e) { console.error('loadLocalUpdateJson failed', e); }
        return null;
    }
    function showWhatsNewManually() {
        // 1) Last pending (after update)
        try {
            const raw = localStorage.getItem('whatsNew');
            if (raw) {
                const pending = JSON.parse(raw);
                if (pending.whatsNew && pending.whatsNew.pages) { showWhatsNewCarousel(pending.whatsNew.pages, pending.version); return; }
            }
        } catch (e) {}
        // 2) Try local file first (works offline, no server needed)
        const local = loadLocalUpdateJson();
        if (local && local.whatsNew && local.whatsNew.pages && local.whatsNew.pages.length > 0) {
            showWhatsNewCarousel(local.whatsNew.pages, local.version);
            return;
        }
        if (local && local.notes && local.notes.length > 0) {
            const pages = local.notes.map(n => ({ title: "What's New", description: n, media: null, buttons: [] }));
            showWhatsNewCarousel(pages, local.version);
            return;
        }
        // 3) Fallback to network
        fetchUpdateManifest().then(info => {
            if (info) lastUpdateInfo = info;
            if (info && info.whatsNew && info.whatsNew.pages && info.whatsNew.pages.length > 0) {
                showWhatsNewCarousel(info.whatsNew.pages, info.version);
            } else if (info && info.notes && info.notes.length > 0) {
                const pages = info.notes.map(n => ({ title: "What's New", description: n, media: null, buttons: [] }));
                showWhatsNewCarousel(pages, info.version);
            } else if (local) {
                showModal('No new features to show yet. Check back after the next update!', { title: "What's New", showCancel: false });
            } else {
                showModal('Could not load What\'s New. Check your internet connection.', { title: "What's New", showCancel: false });
            }
        }).catch((e) => {
            console.error('fetchUpdateManifest failed', e);
            // Final fallback to local and last fetched
            const fallback = loadLocalUpdateJson() || lastUpdateInfo;
            if (fallback && fallback.whatsNew && fallback.whatsNew.pages) {
                showWhatsNewCarousel(fallback.whatsNew.pages, fallback.version);
            } else if (fallback && fallback.notes) {
                const pages = fallback.notes.map(n => ({ title: "What's New", description: n, media: null, buttons: [] }));
                showWhatsNewCarousel(pages, fallback.version);
            } else {
                showModal('Could not load What\'s New. Check your internet connection. (' + (e && e.message ? e.message : 'offline') + ')', { title: "What's New", showCancel: false });
            }
        });
    }
    if (whatsNewBtn) whatsNewBtn.addEventListener('click', showWhatsNewManually);

    // Show welcome on first launch
    try {
        if (!localStorage.getItem('hasSeenWelcome')) {
            setTimeout(showWelcome, 800);
        }
    } catch (e) {}

    // Keep welcome/portfolio in sync with publisher's About (no code change needed)
    fetchUpdateManifest().then(info => {
        if (info && info.about) {
            if (info.about.portfolioUrl) PORTFOLIO_URL = info.about.portfolioUrl;
            if (info.about.welcomeText) {
                const d = document.getElementById('welcome-desc');
                if (d) d.textContent = info.about.welcomeText;
            }
        }
    }).catch(()=>{});

    renderSidebar();

    // Infinite Scroll via scroll event
    assetGrid.addEventListener('scroll', () => {
        // If scrolled near the bottom (within 100px)
        if (assetGrid.scrollTop + assetGrid.clientHeight >= assetGrid.scrollHeight - 100) {
            renderNextChunk();
        }
    });

    // Intersection Observer for Lazy Rendering & Metadata parsing
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                processVisibleAsset(entry.target);
            }
        });
    }, { root: assetGrid.parentElement, rootMargin: '50px' });

    // --- Data Persistence ---
    function loadData() {
        if (fs.existsSync(DATA_PATH)) {
            try { appData = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')); } catch(e){}
        }
        if (!appData.categories) appData.categories = {};
        if (!appData.folders) appData.folders = [];
        if (!appData.folderCache) appData.folderCache = {};
    }
    function saveData() {
        if (!fs.existsSync(path.dirname(DATA_PATH))) {
            fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
        }
        fs.writeFileSync(DATA_PATH, JSON.stringify(appData, null, 2));
    }

    // --- Sidebar Rendering ---
    function renderSidebar() {
        folderList.innerHTML = '';
        categoryList.innerHTML = '';

        for (const cat in appData.categories) {
            const li = document.createElement('li');
            li.className = 'category-row';
            li.innerHTML = `
                <span class="folder-item-icon">⭐</span>
                <span class="folder-name">${cat}</span>
                <button class="delete-btn" title="Remove Category">×</button>
            `;
            
            li.addEventListener('dragover', (e) => {
                e.preventDefault();
                li.classList.add('drag-over');
            });
            li.addEventListener('dragleave', () => li.classList.remove('drag-over'));
            li.addEventListener('drop', (e) => {
                e.preventDefault();
                li.classList.remove('drag-over');
                
                const files = e.dataTransfer.files;
                const plainTextPath = e.dataTransfer.getData('text/plain');
                
                let pathsToAdd = [];

                if (files && files.length > 0) {
                    for (let i=0; i<files.length; i++) {
                        pathsToAdd.push(files[i].path);
                    }
                } else if (plainTextPath) {
                    pathsToAdd.push(plainTextPath);
                }

                if (pathsToAdd.length > 0) {
                    for (let i=0; i<pathsToAdd.length; i++) {
                        const filePath = pathsToAdd[i];
                        if (isJunkFile(path.basename(filePath))) continue;
                        const ext = path.extname(filePath).toLowerCase();
                        if (SUPPORTED_EXTS.includes(ext)) {
                            const normalizedPath = filePath.replace(/\\\\/g, '/');
                            if (!appData.categories[cat].includes(normalizedPath)) {
                                appData.categories[cat].push(normalizedPath);
                            }
                        }
                    }
                    saveData();
                    if (li.classList.contains('active')) loadCategory(cat);
                }
            });

            li.addEventListener('click', (e) => {
                if (e.target.classList.contains('delete-btn')) {
                    delete appData.categories[cat];
                    saveData();
                    renderSidebar();
                    return;
                }
                clearSidebarActive();
                li.classList.add('active');
                loadCategory(cat);
            });
            categoryList.appendChild(li);
        }

        appData.folders.forEach(folderPath => {
            if(fs.existsSync(folderPath)){
                folderList.appendChild(buildFolderTree(folderPath, true));
            }
        });
    }

    function clearSidebarActive() {
        document.querySelectorAll('.category-row, .folder-name-row').forEach(el => el.classList.remove('active'));
    }

    function buildFolderTree(dirPath, isRoot = false) {
        const li = document.createElement('li');
        li.className = 'folder-item';
        
        const folderName = isRoot ? dirPath : path.basename(dirPath);
        const row = document.createElement('div');
        row.className = 'folder-name-row';
        
        let hasChildren = false;
        try {
            const items = fs.readdirSync(dirPath, { withFileTypes: true });
            hasChildren = items.some(item => item.isDirectory());
        } catch(e){}

        const caret = document.createElement('span');
        caret.className = 'caret ' + (hasChildren ? '' : 'empty');
        caret.innerText = '▶';

        row.innerHTML = `<span class="folder-item-icon">📁</span><span class="folder-name" title="${folderName}">${folderName}</span>`;
        row.prepend(caret);
        
        if (isRoot) {
            const delBtn = document.createElement('button');
            delBtn.className = 'delete-btn';
            delBtn.innerText = '×';
            delBtn.style.display = 'none';
            row.appendChild(delBtn);
            row.addEventListener('mouseenter', () => delBtn.style.display = 'inline-block');
            row.addEventListener('mouseleave', () => delBtn.style.display = 'none');
            delBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                appData.folders = appData.folders.filter(f => f !== dirPath);
                if (currentWatchedDir === dirPath) clearFolderWatch();
                saveData();
                renderSidebar();
            });
        }

        li.appendChild(row);

        const childrenContainer = document.createElement('ul');
        childrenContainer.className = 'folder-list folder-children';
        li.appendChild(childrenContainer);

        let loadedChildren = false;

        caret.addEventListener('click', (e) => {
            e.stopPropagation();
            if (!hasChildren) return;
            caret.classList.toggle('open');
            childrenContainer.classList.toggle('open');
            
            if (caret.classList.contains('open') && !loadedChildren) {
                loadedChildren = true;
                try {
                    const items = fs.readdirSync(dirPath, { withFileTypes: true });
                    items.forEach(item => {
                        if (item.isDirectory()) {
                            childrenContainer.appendChild(buildFolderTree(path.join(dirPath, item.name), false));
                        }
                    });
                } catch(e){}
            }
        });

        row.addEventListener('click', async (e) => {
            clearSidebarActive();
            row.classList.add('active');
            await loadFolder(dirPath);
        });

        return li;
    }

    // --- Loading Logic ---
    async function loadCategory(catName) {
        clearFolderWatch();
        currentPathDisplay.innerText = `Category: ${catName}`;
        currentAssets = [];
        const paths = appData.categories[catName] || [];

        loadingIndicator.classList.remove('hidden');
        assetGrid.innerHTML = '';

        for (const fp of paths) {
            if (isJunkFile(path.basename(fp))) continue;
            try {
                const stat = await fs.promises.stat(fp);
                const ext = path.extname(fp).toLowerCase();
                currentAssets.push({ path: fp, name: path.basename(fp), ext, stat, category: catName });
            } catch(e) {}
        }
        loadingIndicator.classList.add('hidden');
        renderGrid();
    }

    async function loadFolder(dirPath) {
        currentPathDisplay.innerText = dirPath;
        assetGrid.innerHTML = '';
        currentAssets = [];

        if (appData.folderCache && appData.folderCache[dirPath]) {
            currentAssets = appData.folderCache[dirPath];
            renderGrid();
            // Background scan to update cache and the visible grid silently
            rescanFolder(dirPath);
        } else {
            loadingIndicator.classList.remove('hidden');
            await scanDirRecursive(dirPath);
            if (!appData.folderCache) appData.folderCache = {};
            appData.folderCache[dirPath] = currentAssets;
            saveData();
            loadingIndicator.classList.add('hidden');
            renderGrid();
        }

        watchFolder(dirPath);
    }

    // --- Live Folder Watching ---
    // Watches the currently open folder (recursively) so newly added/removed
    // files show up automatically, without needing to reopen the panel.
    function clearFolderWatch() {
        if (watchDebounceTimer) {
            clearTimeout(watchDebounceTimer);
            watchDebounceTimer = null;
        }
        if (folderWatcher) {
            try { folderWatcher.close(); } catch(e) {}
            folderWatcher = null;
        }
        currentWatchedDir = null;
    }

    function watchFolder(dirPath) {
        clearFolderWatch();
        currentWatchedDir = dirPath;
        try {
            folderWatcher = fs.watch(dirPath, { recursive: true }, () => {
                if (watchDebounceTimer) clearTimeout(watchDebounceTimer);
                // Debounce: file copies/writes fire multiple change events in a burst
                watchDebounceTimer = setTimeout(() => rescanFolder(dirPath), 500);
            });
        } catch(e) {
            console.error('Could not watch folder for changes:', dirPath, e);
        }
    }

    async function rescanFolder(dirPath) {
        let tempAssets = [];
        await scanDirRecursiveInternal(dirPath, tempAssets);
        appData.folderCache[dirPath] = tempAssets;
        saveData();
        if (currentWatchedDir === dirPath) {
            currentAssets = tempAssets;
            renderGrid();
        }
    }

    async function scanDirRecursive(dir) {
        await scanDirRecursiveInternal(dir, currentAssets);
    }

    async function scanDirRecursiveInternal(dir, targetArray) {
        try {
            const list = await fs.promises.readdir(dir, { withFileTypes: true });
            const tasks = list.map(async (file) => {
                if (isJunkFile(file.name)) return;
                const fullPath = path.join(dir, file.name);
                if (file.isDirectory()) {
                    await scanDirRecursiveInternal(fullPath, targetArray);
                } else {
                    const ext = path.extname(file.name).toLowerCase();
                    if (SUPPORTED_EXTS.includes(ext)) {
                        targetArray.push({ path: fullPath, name: file.name, ext, mtimeMs: 0 }); // Skip stat for speed
                    }
                }
            });
            await Promise.all(tasks);
        } catch(e) { console.error(e); }
    }

    // --- Grid Rendering & Lazy Loading ---
    function renderGrid() {
        observer.disconnect(); // clear old observers
        assetGrid.innerHTML = '';
        renderedCount = 0;
        const search = searchInput.value.toLowerCase();
        const sortVal = sortSelect.value;

        currentFilteredAssets = currentAssets.filter(a => {
            if (isJunkFile(a.name)) return false;
            if (!a.name.toLowerCase().includes(search)) return false;
            
            const kind = getAssetKind(a.ext);
            if (!kind) return false;
            if (activeFilters.hasOwnProperty(kind) && activeFilters[kind] === false) return false;
            
            return true;
        });

        currentFilteredAssets.sort((a, b) => {
            if (sortVal === 'name-asc') return a.name.localeCompare(b.name);
            if (sortVal === 'name-desc') return b.name.localeCompare(a.name);
            if (sortVal === 'date-desc') return (b.mtimeMs || b.stat?.mtimeMs || 0) - (a.mtimeMs || a.stat?.mtimeMs || 0); 
            if (sortVal === 'date-asc') return (a.mtimeMs || a.stat?.mtimeMs || 0) - (b.mtimeMs || b.stat?.mtimeMs || 0);  
            return 0;
        });

        renderNextChunk();
    }

    function renderNextChunk() {
        if (renderedCount >= currentFilteredAssets.length) return;
        const chunk = currentFilteredAssets.slice(renderedCount, renderedCount + CHUNK_SIZE);
        chunk.forEach(asset => createAssetItem(asset));
        renderedCount += CHUNK_SIZE;
    }

    function getHash(str) {
        return crypto.createHash('md5').update(str).digest('hex');
    }

    function formatTime(seconds) {
        if (!seconds) return '';
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m}:${s.toString().padStart(2, '0')}`;
    }

    async function processVisibleAsset(item) {
        const filePath = item.dataset.path;
        const ext = item.dataset.ext;
        const kind = getAssetKind(ext);
        const isAudio = kind === 'audio';
        const isVideo = kind === 'video';
        
        // Fetch Duration using music-metadata (Non-blocking)
        if (!item.dataset.durationParsed && (isAudio || isVideo)) {
            item.dataset.durationParsed = "true";
            try {
                const metadata = await mm.parseFile(filePath, { duration: true, skipCovers: true });
                if (metadata.format && metadata.format.duration) {
                    const badge = item.querySelector('.duration-badge');
                    badge.innerText = formatTime(metadata.format.duration);
                    badge.style.display = 'block';
                }
            } catch(e) {}
        }

        // Generate Waveform for Audio
        if (isAudio && !item.dataset.waveformParsed) {
            item.dataset.waveformParsed = "true";
            const canvas = item.querySelector('.waveform-canvas');
            const hash = getHash(filePath);
            const cacheFile = path.join(WAVEFORM_DIR, hash + '.json');

            if (fs.existsSync(cacheFile)) {
                try {
                    const base64 = fs.readFileSync(cacheFile, 'utf8');
                    drawWaveformData(canvas, JSON.parse(base64));
                } catch(e){}
            } else {
                // Decode Audio (Wrap in try/catch to avoid halting)
                fs.promises.readFile(filePath).then(buffer => {
                    const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
                    getAudioCtx().decodeAudioData(arrayBuffer, (audioBuffer) => {
                        const rawData = audioBuffer.getChannelData(0);
                        const samples = 60; // 60 bars for wider, more visible lines
                        const blockSize = Math.floor(rawData.length / samples);
                        const filteredData = [];
                        for (let i = 0; i < samples; i++) {
                            let blockStart = blockSize * i;
                            let sum = 0;
                            for (let j = 0; j < blockSize; j++) {
                                sum = sum + Math.abs(rawData[blockStart + j]);
                            }
                            filteredData.push(sum / blockSize);
                        }
                        const multiplier = Math.max(...filteredData);
                        const normalizedData = filteredData.map(n => n / multiplier);
                        
                        fs.promises.writeFile(cacheFile, JSON.stringify(normalizedData)).catch(()=>{});
                        drawWaveformData(canvas, normalizedData);
                    }, (e) => { console.error("Error decoding audio data", e); });
                }).catch(e => console.error(e));
            }
        }
    }

    function drawWaveformData(canvas, data) {
        if(!canvas) return;
        const ctx = canvas.getContext('2d');
        canvas.width = canvas.parentElement.clientWidth || 110;
        canvas.height = canvas.parentElement.clientHeight || 70;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)'; // Clean, bright Composer style
        
        const barWidth = canvas.width / data.length;
        const center = canvas.height / 2;
        
        for (let i = 0; i < data.length; i++) {
            const x = i * barWidth;
            // Premiere Composer waveforms are symmetrical with thin bars
            const height = Math.max(data[i] * canvas.height * 0.8, 1);
            const y = center - (height / 2);
            // Use width = barWidth * 0.6 so there is a nice gap, min 1px
            const width = Math.max(barWidth * 0.6, 1);
            ctx.fillRect(x + (barWidth - width)/2, y, width, height);
        }
        
        // Optional center line to make it look even more professional
        ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.fillRect(0, center, canvas.width, 1);
    }

    function createAssetItem(asset) {
        const item = document.createElement('div');
        item.className = 'asset-item';
        // After Effects has no supported way for a CEP panel to drop files
        // onto its Timeline/Project panel (a documented Adobe platform gap,
        // not something fixable on our end - see github.com/Adobe-CEP/
        // CEP-Resources/issues/389). Offering a drag affordance there would
        // just silently fail, so double-click is the only interaction in AE.
        item.draggable = !isAE;
        item.dataset.path = asset.path;
        item.dataset.ext = asset.ext;
        if (isAE) item.title = 'Double-click to add to the active composition at the playhead';

        if (!isAE) {
            item.addEventListener('dragstart', (e) => {
                const filePath = asset.path;
                const fileURL = 'file:///' + filePath.replace(/\\/g, '/');

                // Premiere Pro & standard CEP
                e.dataTransfer.setData('com.adobe.cep.dnd.file.0', filePath);
                e.dataTransfer.setData('text/plain', filePath);
                e.dataTransfer.setData('text/uri-list', fileURL);
                e.dataTransfer.effectAllowed = 'copyMove';

                // Native drag-and-drop into Premiere's Project panel/timeline is
                // handled entirely by the host app once the drag leaves this
                // webview - we get no reliable 'dragend'/'drop' signal back for it.
                // So instead of waiting for an event, start polling the host script
                // right away: it looks for a project item matching this file's path
                // and files it into the right library bin as soon as it shows up.
                if (window.__adobe_cep__) {
                    const escapedPath = filePath.replace(/\\/g, '\\\\');
                    const script = '$._ext.organizeDroppedFile("' + escapedPath + '")';
                    let attempts = 0;
                    const maxAttempts = 15;
                    const poll = setInterval(() => {
                        attempts++;
                        window.__adobe_cep__.evalScript(script, (result) => {
                            if (result === 'Success' || attempts >= maxAttempts) {
                                clearInterval(poll);
                            }
                        });
                    }, 700);
                }
            });
        }

        // Double click to import directly - the only way to add media in AE
        // (see note above), and also supported/reliable in Premiere.
        item.addEventListener('dblclick', () => {
            if (window.__adobe_cep__) {
                const escapedPath = asset.path.replace(/\\/g, '\\\\');
                const script = '$._ext.importFile("' + escapedPath + '")';
                window.__adobe_cep__.evalScript(script, (result) => {
                    if (result && result.indexOf("Error") !== -1) {
                        alert(result);
                    }
                });
            }
        });

        const assetKind = getAssetKind(asset.ext);
        const isVideo = assetKind === 'video';
        const isAudio = assetKind === 'audio';
        const isImage = assetKind === 'image';
        const isSubtitle = assetKind === 'subtitle';
        const isImageRenderable = IMAGE_RENDERABLE_EXTS.includes(asset.ext);
        const fileURI = 'file:///' + asset.path.replace(/\\/g, '/');
        const isSpecialKind = ['project','font','c3d','lut','script','vector','data','preset'].includes(assetKind);

        // Note: No heavy <audio> or <video> tags in the initial DOM! Only placeholders.
        item.innerHTML = `
            <div class="asset-preview">
                <div class="duration-badge"></div>
                ${isAudio ? `<canvas class="waveform-canvas"></canvas><div class="audio-icon">🎵</div>` : ''}
                ${isImage && isImageRenderable ? `<img src="${fileURI}" />` : ''}
                ${isImage && !isImageRenderable ? `<div class="type-icon">🖼️</div>` : ''}
                ${isSubtitle ? `<div class="type-icon">💬</div>` : ''}
                ${isSpecialKind ? `<div class="type-icon">${getAssetIcon(assetKind)}</div>` : ''}
                <div class="media-layer"></div>
                <div class="progress-container"><div class="progress-fill"></div></div>
            </div>
            <div class="asset-info">
                <div class="asset-name" title="${asset.name}">${asset.name}</div>
                <div class="asset-type">${asset.ext.replace('.', '')}</div>
            </div>
        `;

        if (asset.category) {
            const removeBtn = document.createElement('button');
            removeBtn.className = 'delete-btn';
            removeBtn.style.position = 'absolute';
            removeBtn.style.right = '5px';
            removeBtn.style.top = '5px';
            removeBtn.style.zIndex = '15';
            removeBtn.style.background = 'rgba(0,0,0,0.7)';
            removeBtn.style.borderRadius = '50%';
            removeBtn.style.padding = '0 6px';
            removeBtn.innerText = '×';
            removeBtn.title = "Remove from category";
            removeBtn.style.display = 'none';
            item.appendChild(removeBtn);
            
            item.addEventListener('mouseenter', () => removeBtn.style.display = 'block');
            item.addEventListener('mouseleave', () => removeBtn.style.display = 'none');
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                appData.categories[asset.category] = appData.categories[asset.category].filter(p => p !== asset.path);
                saveData();
                loadCategory(asset.category);
            });
        }

        // --- Hover Lazy Loading & Scrubbing ---
        const mediaLayer = item.querySelector('.media-layer');
        const progressContainer = item.querySelector('.progress-container');
        const progressFill = item.querySelector('.progress-fill');
        let mediaElement = null;

        item.addEventListener('mouseenter', () => {
            if (isVideo) {
                mediaElement = document.createElement('video');
                mediaElement.src = fileURI;
                mediaElement.loop = true;
                mediaElement.muted = true;
            } else if (isAudio) {
                mediaElement = document.createElement('audio');
                mediaElement.src = fileURI;
                // Add an image fallback for video layer if needed, but audio plays hidden
            } else { return; }

            mediaLayer.appendChild(mediaElement);
            mediaElement.play().catch(()=>{});

            mediaElement.addEventListener('timeupdate', () => {
                if (mediaElement.duration) {
                    const pct = (mediaElement.currentTime / mediaElement.duration) * 100;
                    progressFill.style.width = pct + '%';
                }
            });

            progressContainer.addEventListener('click', (e) => {
                e.stopPropagation();
                if (mediaElement && mediaElement.duration) {
                    const rect = progressContainer.getBoundingClientRect();
                    const clickX = e.clientX - rect.left;
                    const pct = clickX / rect.width;
                    mediaElement.currentTime = pct * mediaElement.duration;
                }
            });
        });

        item.addEventListener('mouseleave', () => {
            if (mediaElement) {
                mediaElement.pause();
                mediaElement.remove();
                mediaElement = null;
                progressFill.style.width = '0%';
            }
        });

        assetGrid.appendChild(item);
        observer.observe(item); // Start observing for metadata/waveforms
    }

    // --- Action Handlers ---
    function handleAddFolder() {
        if (window.cep && window.cep.fs) {
            const result = window.cep.fs.showOpenDialog(false, true, 'Select a Media Folder', '', null);
            if (result.err === window.cep.fs.NO_ERROR && result.data.length > 0) {
                const selectedPath = result.data[0];
                if (!appData.folders.includes(selectedPath)) {
                    appData.folders.push(selectedPath);
                    saveData();
                    renderSidebar();
                }
            }
        } else { alert("CEP API not available."); }
    }

    function handleAddCategory() {
        const catName = prompt("Enter new category name:");
        if (catName && catName.trim() !== '') {
            const name = catName.trim();
            if (!appData.categories[name]) {
                appData.categories[name] = [];
                saveData();
                renderSidebar();
            } else {
                alert("Category already exists!");
            }
        }
    }
});
