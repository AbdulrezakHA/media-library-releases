const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const ROOT = __dirname;
const PORT = 3415;

function mime(p) {
  if (p.endsWith('.html')) return 'text/html';
  if (p.endsWith('.css')) return 'text/css';
  if (p.endsWith('.js')) return 'application/javascript';
  if (p.endsWith('.json')) return 'application/json';
  if (p.endsWith('.png')) return 'image/png';
  if (p.endsWith('.jpg') || p.endsWith('.jpeg')) return 'image/jpeg';
  if (p.endsWith('.svg')) return 'image/svg+xml';
  return 'text/plain';
}

function send(res, code, body, type) {
  res.writeHead(code, { 'Content-Type': type || 'text/plain', 'Access-Control-Allow-Origin': '*' });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }

  // Serve publisher.html at /
  if (req.method === 'GET' && (req.url === '/' || req.url === '/publisher.html')) {
    const html = fs.readFileSync(path.join(ROOT, 'publisher.html'), 'utf8');
    return send(res, 200, html, 'text/html');
  }
  // Serve static files
  if (req.method === 'GET') {
    let filePath = path.join(ROOT, req.url.split('?')[0]);
    // Prevent directory traversal
    if (!filePath.startsWith(ROOT)) return send(res, 403, 'Forbidden');
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      return send(res, 200, fs.readFileSync(filePath), mime(filePath));
    }
    // Also serve update.json
    if (req.url.startsWith('/update.json')) {
      const p = path.join(ROOT, 'update.json');
      if (fs.existsSync(p)) return send(res, 200, fs.readFileSync(p), 'application/json');
      return send(res, 404, 'Not found');
    }
  }

  if (req.method === 'POST' && req.url === '/api/save') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const ver = data.version;
        const msg = data.message || `Version ${ver} available!`;
        const portfolio = data.portfolio || (data.about && data.about.portfolioUrl) || 'https://abdulrezak.com';
        const welcomeText = data.welcomeText || (data.about && data.about.welcomeText) || '';
        const pages = data.pages || [];

        // Build whatsNew structure and write media files
        const whatsNew = { title: `What's New in v${ver}`, pages: [] };
        const whatsDir = path.join(ROOT, 'whatsnew', ver);
        fs.mkdirSync(whatsDir, { recursive: true });

        for (let i = 0; i < pages.length; i++) {
          const p = pages[i];
          let mediaRel = null;
          if (p.mediaData && p.mediaData.startsWith('data:')) {
            const m = p.mediaData.match(/^data:([^;]+);base64,(.+)$/);
            if (m) {
              const ext = m[1].includes('video') ? '.mp4' : '.jpg';
              const fileName = p.mediaName ? p.mediaName.replace(/[^a-zA-Z0-9._-]/g,'_') : `page${i+1}${ext}`;
              const safeName = fileName;
              const buf = Buffer.from(m[2], 'base64');
              fs.writeFileSync(path.join(whatsDir, safeName), buf);
              mediaRel = `whatsnew/${ver}/${safeName}`;
            }
          } else if (p.mediaName && p.mediaData) {
            // fallback
            mediaRel = p.media;
          }
          whatsNew.pages.push({
            title: p.title,
            description: p.description,
            media: mediaRel,
            mediaType: p.mediaType || 'image',
            buttons: p.buttons || []
          });
        }

        // Load public repo slug from .publish-config.json if exists
        let publicRepo = 'AbdulrezakHA/media-library-releases';
        try {
          const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, '.publish-config.json'), 'utf8'));
          if (cfg.publicRepo) publicRepo = cfg.publicRepo;
        } catch {}

        const about = { portfolioUrl: portfolio, welcomeText: welcomeText };
        const updateJson = {
          version: ver,
          type: 'hot',
          message: msg,
          whatsNew: whatsNew,
          about: about,
          notes: pages.map(p => p.description),
          zipUrl: `https://github.com/${publicRepo}/releases/latest/download/MediaLibrary.zip`,
          zxpUrl: `https://github.com/${publicRepo}/releases/latest/download/MediaLibrary.zxp`
        };
        fs.writeFileSync(path.join(ROOT, 'update.json'), JSON.stringify(updateJson, null, 2));

        // Patch CURRENT_VERSION and PORTFOLIO_URL in js/main.js
        const mainJsPath = path.join(ROOT, 'js', 'main.js');
        if (fs.existsSync(mainJsPath)) {
          let txt = fs.readFileSync(mainJsPath, 'utf8');
          txt = txt.replace(/const CURRENT_VERSION = '[^']+';/, `const CURRENT_VERSION = '${ver}';`);
          txt = txt.replace(/const PORTFOLIO_URL = '[^']+';/, `const PORTFOLIO_URL = '${portfolio.replace(/'/g, "\\'")}';`);
          // Also patch welcome text if provided (replace the hardcoded paragraph)
          if (welcomeText) {
            // Replace the welcome body text between the two <p> tags in the HTML is handled via JS, but we also store in update.json for runtime fetch
          }
          fs.writeFileSync(mainJsPath, txt);
        }
        // Patch manifest
        const manifestPath = path.join(ROOT, 'CSXS', 'manifest.xml');
        if (fs.existsSync(manifestPath)) {
          let xml = fs.readFileSync(manifestPath, 'utf8');
          xml = xml.replace(/ExtensionBundleVersion="[^"]+"/, `ExtensionBundleVersion="${ver}"`);
          xml = xml.replace(/<Extension Id="com\.custom\.medialibrary\.panel" Version="[^"]+"/, `<Extension Id="com.custom.medialibrary.panel" Version="${ver}"`);
          xml = xml.replace(/<Extension Id="com\.custom\.medialibrary\.panel2" Version="[^"]+"/, `<Extension Id="com.custom.medialibrary.panel2" Version="${ver}"`);
          xml = xml.replace(/<Extension Id="com\.custom\.medialibrary\.panel3" Version="[^"]+"/, `<Extension Id="com.custom.medialibrary.panel3" Version="${ver}"`);
          fs.writeFileSync(manifestPath, xml);
        }

        send(res, 200, JSON.stringify({ ok: true, message: `Saved v${ver} with ${pages.length} pages` }), 'application/json');
      } catch (e) {
        send(res, 500, JSON.stringify({ ok: false, error: e.message }), 'application/json');
      }
    });
    return;
  }

  if (req.method === 'POST' && req.url === '/api/publish') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      let ver = '';
      try { ver = JSON.parse(body).version || ''; } catch {}
      console.log(`\n[Publish] Starting publish for v${ver}...`);
      console.log(`[Publish] If this hangs, close this publisher and double-click publish.cmd instead (more reliable)`);
      const ps = `powershell -NoProfile -ExecutionPolicy Bypass -File "${path.join(ROOT, 'publish.ps1')}"`;
      const cmd = ver ? `${ps} -Version ${ver} -NoPause` : ps;
      // Use visible window so git credential prompts can show; stream output to this console
      const child = require('child_process').spawn('powershell', ['-NoProfile','-ExecutionPolicy','Bypass','-File', path.join(ROOT, 'publish.ps1'), ...(ver?['-Version', ver, '-NoPause']:[])], { cwd: ROOT, windowsHide: false });
      let out = '';
      child.stdout.on('data', d => { out += d; process.stdout.write(d); });
      child.stderr.on('data', d => { out += d; process.stderr.write(d); });
      const timeout = setTimeout(() => {
        try { child.kill(); } catch {}
        console.log('[Publish] Timeout after 90s — try publish.cmd directly');
        send(res, 500, JSON.stringify({ ok: false, error: 'Publish timed out after 90s. Close publisher and double-click publish.cmd to push manually. Log:\n' + out }), 'application/json');
      }, 90000);
      child.on('close', (code) => {
        clearTimeout(timeout);
        if (code !== 0) {
          console.log(`[Publish] Failed with code ${code}`);
          return send(res, 500, JSON.stringify({ ok: false, error: out || `Exit code ${code}. Try publish.cmd directly.` }), 'application/json');
        }
        const m = out.match(/https:\/\/github\.com\/[^\s]+\/releases\/tag\/[^\s]+/);
        console.log(`[Publish] Done! ${m?m[0]:''}`);
        send(res, 200, JSON.stringify({ ok: true, message: 'Published', url: m ? m[0] : null, log: out }), 'application/json');
      });
      child.on('error', (err) => {
        clearTimeout(timeout);
        send(res, 500, JSON.stringify({ ok: false, error: err.message }), 'application/json');
      });
    });
    return;
  }

  send(res, 404, 'Not found');
});

server.listen(PORT, () => {
  console.log(`Publisher running at http://localhost:${PORT}`);
  console.log('Opening browser...');
  const openCmd = process.platform === 'win32' ? `start http://localhost:${PORT}` : `open http://localhost:${PORT}`;
  exec(openCmd, () => {});
});
