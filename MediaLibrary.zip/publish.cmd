@echo off
echo Starting publish...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish.ps1"
echo.
echo --- Exit code: %errorlevel% ---
echo If you saw an error above, copy it and send it to me.
pause
