# Publisher UI + Adobe-Style Popup — UI Guide for AI
*How we built the visual update publisher and the multi-page What's New tour. Copy this to any CEP plugin.*

---

## 1) What the UI Is

**Publisher (`publisher.html` + `publisher-server.js` + `publisher.cmd`):** Visual, no-cmd-typing editor. Left = form, Right = live preview that looks **exactly** like the plugin's popup. User sets Version + Banner message + Portfolio URL + Welcome text, clicks `+ Add Page` per feature, drops **image/video** per page, adds **Buttons** (label + URL + Primary), sees Adobe-style preview, clicks **Save & Publish →** → writes `update.json` + `whatsnew/<ver>/media` + patches `CURRENT_VERSION`/`PORTFOLIO_URL` + pushes + creates Release.

**Popup (`#whatsnew-overlay` in `index.html`):** Adobe-like carousel. Left nav = list of features, Right top = image/video header, Right middle = title + description + buttons, Bottom = dots + Previous/Next/Done, Close X. Loaded after update via `file://` (bundled in zip, no server).

**What's New replay:** Footer button `What's New` reopens the same tour anytime (offline fallback to local `update.json`).

---

## 2) Files to Copy

| File | UI Part |
|------|---------|
| `publisher.html` (22800 bytes) | Visual editor + live preview |
| `publisher-server.js` | Tiny Node server: serves `publisher.html` at `http://localhost:3415`, `POST /api/save` (writes `update.json` + `whatsnew/` + patches version), `POST /api/publish` (spawns `publish.ps1 -Version x -NoPause`) |
| `publisher.cmd` | `where node` → `node publisher-server.js` else `start publisher.html` |
| `index.html` → `#whatsnew-overlay`, `#welcome-overlay`, `.sidebar-footer` (`#version-indicator`, `#whatsnew-btn`, `#about-btn`, `#portfolio-link`) | Markup |
| `css/style.css` → `#whatsnew-overlay`, `.whatsnew-box`, `.whatsnew-layout`, `.whatsnew-nav`, `.whatsnew-media`, `.whatsnew-text`, `.whatsnew-footer`, `.sidebar-footer`, `#welcome-overlay` | Styles |
| `js/main.js` → `PORTFOLIO_URL`, `showWhatsNewCarousel()`, `resolveWhatsNewMedia()`, `loadLocalUpdateJson()`, `showWhatsNewManually()`, welcome handlers, version badge double-click | Logic |

---

## 3) Publisher UI — How It's Built (`publisher.html`)

**Layout:** `header` (Load + Save & Publish) + `.main` (`.editor` 42% left, `.preview-wrap` flex right). Editor is dark, preview reuses `css/style.css`'s `.whatsnew-box` scaled 0.92.

**State:**
```js
let pages = [
  { title, description, media: dataURL|null, mediaFile: File|null, mediaType: 'image'|'video',
    buttons: [{label, url, primary}] }
];
let previewIndex = 0;
```

**Editor rendering (`renderEditor()`):** For each `pages[i]` creates `.page-card` with: Title `<input>`, Description `<textarea>`, Media `.media-drop` (click → hidden `<input type=file accept=image/*,video/*>` → `handleMedia()` reads as dataURL, sets `media` + `mediaFile`), MediaType `<select>`, Buttons list (`.btn-row` per button: label, url, primary checkbox, ×). `oninput`/`onchange` calls `renderPreview()` live.

**Media handling:** `handleMedia(i,file)` → `mediaType = file.type.startsWith('video')?'video':'image'` → `FileReader.readAsDataURL` → `pages[i].media = dataURL`, `pages[i].mediaFile = file` → `renderEditor()` + `renderPreview()` + toast. Drop also supported via `.media-drop` click; drag handled via `handleMedia`.

**Preview (`renderPreview()`):** Reads `pages[previewIndex]`, builds `mediaHtml` (`<img>` or `<video autoplay loop muted>` from `p.media` dataURL), `navItems` + `dots` from `pages`, `btns` from `p.buttons`, injects a full `.whatsnew-box` into `.preview-stage`. Nav/dots `onclick` sets `previewIndex` and re-renders. Previous/Next buttons handle `previewIndex++/--` and `Done`.

**Load (`loadFromProject()`):** `fetch('update.json')` → if `whatsNew.pages` map to `pages` (+ `media` stays as string path, `mediaFile=null`), if `about` set portfolio/welcomeText inputs. Also handles legacy `notes`.

**Save & Publish (`saveAndPublish()`):**
1. Read `ver`, `msg`, `portfolio`, `welcomeText` from inputs, validate `^\d+\.\d+\.\d+$`.
2. Build `whatsNew = { title: 'What\'s New in v'+ver, pages: pages.map(p=>({title,description,media:null,mediaType,buttons})) }`.
3. If `location.protocol` is `http` (running via `publisher-server.js`):
   - `payload = { version:ver, message:msg, portfolio, welcomeText, whatsNew, pages: pages.map(p=>({title,description,mediaType,mediaData:p.media,mediaName:p.mediaFile?.name,buttons})) }`
   - `POST /api/save` → server writes `whatsnew/<ver>/file`, `update.json` with `whatsNew` + `about: {portfolioUrl,welcomeText}`, patches `js/main.js` `CURRENT_VERSION`/`PORTFOLIO_URL` + manifest.
   - Show overlay `Saving...` → on ok show `Publishing...` → `POST /api/publish {version:ver}` → server spawns `publish.ps1 -Version ver -NoPause` with `windowsHide:false` + streams to console, 90s timeout.
   - On success `showPublishDone(url,ver)` → big green `✓ Published vX!` + `View Release` link.
4. Else if `window.showDirectoryPicker` (Chrome/Edge file:// fallback): pick project folder, write `whatsnew/<ver>/` files via `getDirectoryHandle`/`createWritable`, write `update.json` + patch `js/main.js`, toast `Saved! Now double-click publish.cmd`.
5. Else download `update.json` as Blob.

**Key UX:** No confirm dialog after save — auto goes to publish. Overlay `publish-overlay` with spinner → `Saving...` → `Publishing...` → `✓ Published` + link. The old `confirm('Saved! Now push?')` was removed because users missed it.

---

## 4) Popup UI — How It's Built

**`index.html` `#whatsnew-overlay`:**
```html
<div id="whatsnew-overlay" class="hidden">
  <div class="whatsnew-box">
    <button id="whatsnew-close" class="whatsnew-close">×</button>
    <div class="whatsnew-layout">
      <div class="whatsnew-nav">
        <div class="whatsnew-welcome">Welcome to<br><span id="whatsnew-version-title">Media Library</span></div>
        <ul id="whatsnew-nav-list"></ul>
      </div>
      <div class="whatsnew-content">
        <div id="whatsnew-media" class="whatsnew-media"></div>
        <div class="whatsnew-text">
          <h3 id="whatsnew-page-title"></h3>
          <p id="whatsnew-page-desc"></p>
          <div id="whatsnew-page-buttons" class="whatsnew-buttons"></div>
        </div>
        <div class="whatsnew-footer">
          <div id="whatsnew-dots" class="whatsnew-dots"></div>
          <div class="whatsnew-arrows">
            <button id="whatsnew-prev" class="modal-btn secondary">Previous</button>
            <button id="whatsnew-next" class="modal-btn primary">Next</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
```

**`css/style.css` excerpt:**
```css
#whatsnew-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.75);z-index:3500;display:flex;justify-content:center;align-items:center;backdrop-filter:blur(4px)}
.whatsnew-box{width:780px;height:520px;background:#1e1e1e;border:1px solid #333;border-radius:10px;overflow:hidden;display:flex;flex-direction:column}
.whatsnew-layout{display:flex;flex:1;overflow:hidden}
.whatsnew-nav{width:210px;background:#2a2a2a;border-right:1px solid #333;padding:28px 0 16px;display:flex;flex-direction:column}
.whatsnew-nav-item{padding:10px 20px;font-size:11px;color:#888;cursor:pointer;border-left:2px solid transparent}
.whatsnew-nav-item.active{color:white;border-left-color:var(--accent);background:rgba(45,140,235,.12)}
.whatsnew-media{height:280px;background:#000;display:flex;align-items:center;justify-content:center;overflow:hidden}
.whatsnew-media img,.whatsnew-media video{width:100%;height:100%;object-fit:cover}
.whatsnew-text{padding:18px 22px;flex:1;overflow-y:auto;background:#121212}
.whatsnew-footer{display:flex;justify-content:space-between;align-items:center;padding:12px 22px;background:#121212;border-top:1px solid #222}
.whatsnew-dot{width:7px;height:7px;border-radius:50%;background:#3a3a3a;cursor:pointer}
.whatsnew-dot.active{background:var(--accent);transform:scale(1.2)}
```

**`js/main.js` carousel:**
```js
let PORTFOLIO_URL = 'https://abdulrezak.com';
let lastUpdateInfo = null;

function resolveWhatsNewMedia(p){
  if(!p) return null;
  if(p.startsWith('http')||p.startsWith('file://')||p.startsWith('data:')) return p;
  const extPath = window.__adobe_cep__.getSystemPath('extension');
  return 'file:///' + path.join(extPath, p).replace(/\\/g,'/');
}
function showWhatsNewCarousel(pages, version){
  let current = 0;
  const overlay=document.getElementById('whatsnew-overlay'), navList=..., titleEl=..., descEl=..., mediaEl=..., dotsEl=..., btnsEl=..., verEl=..., prevBtn=..., nextBtn=..., closeBtn=...;
  function render(){
    navList.innerHTML=''; dotsEl.innerHTML='';
    pages.forEach((p,i)=>{
      const li=document.createElement('li'); li.className='whatsnew-nav-item'+(i===current?' active':''); li.textContent=p.title; li.onclick=()=>{current=i;render();}; navList.appendChild(li);
      const dot=document.createElement('div'); dot.className='whatsnew-dot'+(i===current?' active':''); dot.onclick=()=>{current=i;render();}; dotsEl.appendChild(dot);
    });
    const page=pages[current];
    titleEl.textContent=page.title; descEl.textContent=page.description;
    mediaEl.innerHTML='';
    if(page.media){
      const url=resolveWhatsNewMedia(page.media), isVideo=/\.(mp4|webm|mov)$/i.test(page.media)||page.mediaType==='video';
      if(isVideo){ const v=document.createElement('video'); v.src=url; v.autoplay=true; v.loop=true; v.muted=true; mediaEl.appendChild(v); v.play().catch(()=>{}); }
      else { const img=document.createElement('img'); img.src=url; img.onerror=()=>mediaEl.innerHTML='<div class=media-placeholder>🖼️</div>'; mediaEl.appendChild(img); }
    } else mediaEl.innerHTML='<div class=media-placeholder>✨</div>';
    btnsEl.innerHTML='';
    (page.buttons||[]).forEach(b=>{
      const btn=document.createElement('button'); btn.className='modal-btn '+(b.primary?'primary':'secondary'); btn.textContent=b.label;
      btn.onclick=()=>{ const url=b.url; try{ window.cep.util.openURLInDefaultBrowser(url);}catch{ window.open(url,'_blank'); } };
      btnsEl.appendChild(btn);
    });
    prevBtn.style.visibility=current===0?'hidden':'visible';
    nextBtn.textContent=current===pages.length-1?'Done':'Next';
  }
  prevBtn.onclick=()=>{ if(current>0){current--;render();} };
  nextBtn.onclick=()=>{ if(current<pages.length-1){current++;render();} else overlay.classList.add('hidden'); };
  closeBtn.onclick=()=>overlay.classList.add('hidden');
  overlay.onclick=e=>{ if(e.target===overlay) overlay.classList.add('hidden'); };
  render(); overlay.classList.remove('hidden');
}
```

**Media without server:** `page.media` is `whatsnew/1.0.x/file.jpg` relative to extension root. After `applyHotUpdate` extracts zip, the file exists locally, so `resolveWhatsNewMedia` returns `file:///C:/.../CEP/extensions/YourPlugin/whatsnew/1.0.x/file.jpg` — no hosting, no CORS, works offline. `publisher-server.js` writes that file via `Buffer.from(dataURL.split(',')[1],'base64')` into `whatsnew/<ver>/`.

**Footer + Welcome (part of same UI):**
- `.sidebar-footer` with `#version-indicator` (`v`+`CURRENT_VERSION`), `#whatsnew-btn`, `#about-btn`, `#portfolio-link` (`.portfolio-btn` blue).
- `#welcome-overlay` — same dark style, shows on first launch if `!localStorage.hasSeenWelcome`, has `#welcome-desc` + `Support the creator →` → `openPortfolio()` via `PORTFOLIO_URL`.
- Double-click version badge → `window.__adobe_cep__.showDevTools()` (Ctrl+Shift+J doesn't work in CEP).

---

## 5) Data Flow

`publisher.html` → `POST /api/save` → writes `whatsnew/<ver>/media` + `update.json` `{version, message, whatsNew:{pages}, about:{portfolioUrl,welcomeText}, notes, zipUrl}` + patches `js/main.js` `CURRENT_VERSION`/`PORTFOLIO_URL` + manifest → `POST /api/publish` → `publish.ps1 -Version ver -NoPause` → `robocopy` whole project (excluding `publisher.*`, `node_modules`, `.git`) + re-adds `whatsnew/` → `Compress-Archive` → `git push` private + public (`update.json` only) → `gh release create vX MediaLibrary.zip`.

Panel on next launch: `fetchUpdateManifest()` with `?t=Date.now()` (bust CDN) + BOM `replace(/^\uFEFF/,'')` → if `compareVersions(CURRENT_VERSION, info.version) < 0` → banner → `Install Now` → `applyHotUpdate(info.zipUrl)` → `localStorage.setItem('whatsNew', JSON.stringify({version, whatsNew, notes}))` → `location.reload()` → `showWhatsNewIfPending()` reads `whatsNew` → `showWhatsNewCarousel()` → stores `lastUpdateInfo` + `lastWhatsNew` so footer `What's New` replays offline via `loadLocalUpdateJson()` (tries `extension/update.json`, `cep.fs`, `lastUpdateInfo`).

---

## 6) Replication Checklist (for AI)

- [ ] Copy `publisher.html`, `publisher-server.js`, `publisher.cmd` (ensure `publisher-server.js` adds `;C:\Program Files\GitHub CLI` to `PATH` and uses `-NoPause` + `windowsHide:false` + streams to console, 90s timeout).
- [ ] Copy `index.html` overlays + footer, `css` for `whatsnew`/`welcome`/`sidebar-footer`, `js` helpers + `PORTFOLIO_URL` + `lastUpdateInfo` + `loadLocalUpdateJson` (no `__dirname`, handle BOM, try `cep.fs`).
- [ ] Change `UPDATE_MANIFEST_URL` and `PORTFOLIO_URL` per plugin.
- [ ] Ensure `publish.ps1` preserves `whatsNew`/`about` when bumping version (don't overwrite with empty `notes` prompt if `whatsNew` exists) and includes `about` in `update.json` + `ConvertTo-Json -Depth 5`.
- [ ] Ensure `robocopy` excludes `publisher.*` but re-adds `whatsnew/` into zip.
- [ ] Test: `publisher.cmd` → `http://localhost:3415` → add page with image/video + button with `https://` → preview → Save & Publish → check `raw.githubusercontent.com/.../update.json` has `whatsNew.pages[].media` as `whatsnew/<ver>/...` → install on test machine with older version → banner → Install → tour shows image/video + buttons link via `cep.util.openURLInDefaultBrowser`.

