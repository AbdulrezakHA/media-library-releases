// JSON polyfill for ExtendScript (which lacks native JSON)
if (typeof JSON === 'undefined') {
    JSON = {};
    JSON.parse = function(str) { return eval('(' + str + ')'); };
    JSON.stringify = function(obj) {
        if (obj instanceof Array) {
            var parts = [];
            for (var i = 0; i < obj.length; i++) parts.push(JSON.stringify(obj[i]));
            return '[' + parts.join(',') + ']';
        }
        if (typeof obj === 'object' && obj !== null) {
            var pairs = [];
            for (var k in obj) {
                if (obj.hasOwnProperty(k)) {
                    var val = obj[k];
                    var v;
                    if (typeof val === 'string') v = '"' + val.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r') + '"';
                    else if (typeof val === 'number') v = String(val);
                    else if (typeof val === 'boolean') v = val ? 'true' : 'false';
                    else if (val === null) v = 'null';
                    else if (typeof val === 'object') v = JSON.stringify(val);
                    else v = 'null';
                    pairs.push('"' + k.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '":' + v);
                }
            }
            return '{' + pairs.join(',') + '}';
        }
        if (typeof obj === 'string') return '"' + obj.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n') + '"';
        return String(obj);
    };
}

// Host Script for Premiere Pro / After Effects
// Drag and drop is handled by CEP frontend via com.adobe.cep.dnd.file.0
// Premiere/AE import the dropped file natively, so we can't intercept the
// drop itself - instead we let it land, then find it and file it into the
// right library bin/folder. Double-click import goes straight to the bin.

function isAfterEffects() {
    // app.name only exists on AE's Application object; Premiere's doesn't
    // have it, so detect the host via BridgeTalk.appName instead, which
    // every Adobe ExtendScript host defines reliably.
    return BridgeTalk.appName.indexOf("aftereffects") !== -1;
}

function arrayContains(arr, value) {
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] === value) return true;
    }
    return false;
}

// Keep these in sync with the matching lists in js/main.js - ExtendScript
// runs in a separate JS engine so the lists can't be shared directly.
var VIDEO_EXTS = ['.mp4', '.mov', '.avi', '.mkv', '.m4v', '.mxf', '.wmv', '.webm', '.r3d', '.braw', '.m2ts', '.mpg'];
var AUDIO_EXTS = ['.wav', '.mp3', '.m4a', '.aac', '.flac', '.ogg', '.aif', '.aiff', '.wma'];
var IMAGE_EXTS = ['.jpg', '.jpeg', '.png', '.gif', '.tif', '.tiff', '.bmp', '.webp', '.psd', '.svg', '.exr', '.dpx', '.psb', '.nef', '.cr2', '.arw', '.heic'];
var SUBTITLE_EXTS = ['.srt', '.vtt', '.stl', '.scc', '.mcc', '.ttml', '.dfxp', '.sbv'];
var PROJECT_EXTS = ['.aep', '.aepx', '.aet', '.prproj', '.ffx', '.mogrt'];
var FONT_EXTS = ['.ttf', '.otf', '.woff', '.woff2'];
var C3D_EXTS = ['.c4d', '.obj', '.fbx', '.glb', '.gltf', '.stl', '.3ds', '.dae', '.ply', '.abc', '.usd', '.usda', '.usdc', '.usdz'];
var LUT_EXTS = ['.cube', '.3dl', '.look'];
var SCRIPT_EXTS = ['.jsx', '.jsxbin'];
var VECTOR_EXTS = ['.ai', '.eps'];
var DATA_EXTS = ['.json', '.mgjson', '.csv', '.tsv', '.txt', '.xml'];
var PRESET_EXTS = ['.epr', '.sqpreset'];
var MUSIC_MIN_SECONDS = 60; // audio this long or longer is treated as music, not SFX

// Every top-level/sub-library bin name either organize mode creates. An item
// is considered "plugin-organized" (safe to re-file on a later run, in
// either mode) if its IMMEDIATE parent bin's name is in this set, no matter
// how deep that bin is nested (e.g. "MyEdit/Video Library" or "Shared
// Files/Video Library" both count, via the "Video Library" leaf name).
// Anything else (e.g. a user's own "Camera 1" folder) is left alone.
var MANAGED_BIN_NAMES = {
    'Video Library': true, 'SFX Library': true, 'Music Library': true, 'Images Library': true,
    'Solids': true, 'Sequences': true, 'Nests': true, 'Motion Graphics Templates': true,
    'Linked Comps': true, 'Offline': true, 'Unused': true, 'Shared Files': true, 'Subtitles': true,
    'Projects': true, 'Fonts': true, '3D': true, 'LUTs': true, 'Scripts': true, 'Vectors': true, 'Data': true, 'Presets': true,
    // AE-specific names (Comps/Nested Comps instead of Sequences/Nests, since
    // that's AE's own terminology).
    'Comps': true, 'Nested Comps': true
};

// Label/color slot per managed folder name, applied whenever that folder is
// created or looked up (see ppGetOrCreateBin/aeGetOrCreateFolder below).
// Both Premiere and AE let the user rename/recolor each numbered slot in
// their own Label preferences, so this assigns a distinct SLOT NUMBER per
// category rather than promising a specific color - what that slot actually
// looks like depends on each user's own label palette. Kept to 1-13, safely
// within both apps' typical minimum range of 16 slots.
var LABEL_COLORS = {
    'Video Library': 1, 'SFX Library': 2, 'Music Library': 3, 'Images Library': 4,
    'Solids': 5, 'Sequences': 6, 'Comps': 6, 'Nests': 7, 'Nested Comps': 7,
    'Motion Graphics Templates': 8, 'Linked Comps': 9, 'Subtitles': 10,
    'Offline': 11, 'Unused': 12, 'Shared Files': 13,
    'Projects': 14, 'Fonts': 15, '3D': 16, 'LUTs': 14, 'Scripts': 15, 'Vectors': 16, 'Data': 14, 'Presets': 15
};

function isManagedLocation(parentPath) {
    if (parentPath === '') return true;
    var segments = parentPath.split('/');
    var immediateParent = segments[segments.length - 1];
    return MANAGED_BIN_NAMES.hasOwnProperty(immediateParent);
}

function extOf(filePath) {
    var dot = filePath.lastIndexOf('.');
    return dot !== -1 ? filePath.substring(dot).toLowerCase() : '';
}

function getLibraryFolderName(filePath) {
    var ext = extOf(filePath);
    if (ext === '.mogrt') return 'Motion Graphics Templates';
    if (arrayContains(SUBTITLE_EXTS, ext)) return 'Subtitles';
    if (arrayContains(PROJECT_EXTS, ext)) return 'Projects';
    if (arrayContains(FONT_EXTS, ext)) return 'Fonts';
    if (arrayContains(C3D_EXTS, ext)) return '3D';
    if (arrayContains(LUT_EXTS, ext)) return 'LUTs';
    if (arrayContains(SCRIPT_EXTS, ext)) return 'Scripts';
    if (arrayContains(VECTOR_EXTS, ext)) return 'Vectors';
    if (arrayContains(DATA_EXTS, ext)) return 'Data';
    if (arrayContains(PRESET_EXTS, ext)) return 'Presets';
    if (arrayContains(AUDIO_EXTS, ext)) return 'SFX Library';
    if (arrayContains(VIDEO_EXTS, ext)) return 'Video Library';
    if (arrayContains(IMAGE_EXTS, ext)) return 'Images Library';
    return null;
}

// --- Premiere Pro helpers ---
// Premiere's exact API for this is unverified as of writing - setColorLabel()
// is the more recently-documented method, but ProjectItem.label as a plain
// settable property also exists in some API versions, so this tries both
// and quietly does nothing if neither works.
function ppSetLabel(item, index) {
    try {
        if (typeof item.setColorLabel === 'function') {
            item.setColorLabel(index);
            return;
        }
    } catch (e) {}
    try { item.label = index; } catch (e) {}
}

function ppGetOrCreateBin(parentBin, name) {
    var bin = null;
    for (var i = 0; i < parentBin.children.numItems; i++) {
        var child = parentBin.children[i];
        if (child.type === ProjectItemType.BIN && child.name === name) { bin = child; break; }
    }
    if (!bin) bin = parentBin.createBin(name);
    // Applied every time (not just on creation) so a bin from before this
    // feature existed, or manually re-colored, stays consistent with the
    // rest of this category.
    if (LABEL_COLORS.hasOwnProperty(name)) ppSetLabel(bin, LABEL_COLORS[name]);
    return bin;
}

// Walks a "/"-joined bin path from root, creating any bins that don't exist.
// "" (empty path) resolves to the root itself.
function getOrCreateBinPath(root, pathStr) {
    if (!pathStr) return root;
    var segments = pathStr.split('/');
    var current = root;
    for (var i = 0; i < segments.length; i++) {
        if (segments[i]) current = ppGetOrCreateBin(current, segments[i]);
    }
    return current;
}

function ppFindItemByPath(bin, filePath) {
    for (var i = 0; i < bin.children.numItems; i++) {
        var child = bin.children[i];
        if (child.type === ProjectItemType.BIN) {
            var found = ppFindItemByPath(child, filePath);
            if (found) return found;
        } else {
            try {
                if (child.getMediaPath && child.getMediaPath() === filePath) return child;
            } catch (e) {}
        }
    }
    return null;
}

// --- After Effects helpers ---
// Scoped to a specific parent folder (defaults to the project root) -
// unscoped-by-parent would incorrectly match a same-named folder sitting
// anywhere else in the project.
function aeSetLabel(item, index) {
    try { item.label = index; } catch (e) {}
}

function aeGetOrCreateFolder(project, name, parentFolder) {
    var parent = parentFolder || project.rootFolder;
    var folder = null;
    for (var i = 1; i <= project.numItems; i++) {
        var item = project.item(i);
        if (item instanceof FolderItem && item.name === name && item.parentFolder === parent) { folder = item; break; }
    }
    if (!folder) {
        folder = project.items.addFolder(name);
        folder.parentFolder = parent;
    }
    // Applied every time (not just on creation) so a folder from before this
    // feature existed, or manually re-colored, stays consistent with the
    // rest of this category.
    if (LABEL_COLORS.hasOwnProperty(name)) aeSetLabel(folder, LABEL_COLORS[name]);
    return folder;
}

// "/"-joined chain of folder names from root down to (but not including)
// the item itself - "" means the item sits directly at project root.
function aeGetFolderPath(item) {
    var segments = [];
    var f = item.parentFolder;
    while (f && f !== app.project.rootFolder) {
        segments.unshift(f.name);
        f = f.parentFolder;
    }
    return segments.join('/');
}

// Walks a "/"-joined folder path from root, creating any folders that don't
// exist. "" (empty path) resolves to the root itself. AE's equivalent of
// getOrCreateBinPath.
function aeGetOrCreateFolderPath(project, pathStr) {
    if (!pathStr) return project.rootFolder;
    var segments = pathStr.split('/');
    var current = project.rootFolder;
    for (var i = 0; i < segments.length; i++) {
        if (segments[i]) current = aeGetOrCreateFolder(project, segments[i], current);
    }
    return current;
}

// AE's equivalent of buildUsedItemIds/buildPerSequenceUsage: scans every
// composition's layers for AVLayer.source (the underlying FootageItem or
// nested CompItem a layer displays) to determine what's actually used.
function aeBuildUsedItemIds(project) {
    var usedIds = {};
    for (var i = 1; i <= project.numItems; i++) {
        var item = project.item(i);
        if (!(item instanceof CompItem)) continue;
        for (var l = 1; l <= item.numLayers; l++) {
            try {
                var layer = item.layer(l);
                var source = layer.source;
                if (source && source.id) usedIds[source.id] = true;
            } catch (e) {}
        }
    }
    return usedIds;
}

// Per-composition version: { compItemId: { itemId: true, ... } } - which
// items each individual comp directly uses as a layer source. Needed for
// per-composition organizing, where "used by exactly one comp" vs "used by
// several" determines whether a file goes into that comp's own folder or
// into Shared Files.
function aeBuildPerCompUsage(project) {
    var usage = {};
    for (var i = 1; i <= project.numItems; i++) {
        var item = project.item(i);
        if (!(item instanceof CompItem)) continue;
        var used = {};
        for (var l = 1; l <= item.numLayers; l++) {
            try {
                var layer = item.layer(l);
                var source = layer.source;
                if (source && source.id) used[source.id] = true;
            } catch (e) {}
        }
        usage[item.id] = used;
    }
    return usage;
}

function aeGetDurationSeconds(item) {
    try {
        if (typeof item.duration === 'number' && !isNaN(item.duration)) return item.duration;
    } catch (e) {}
    return null;
}

// --- Offline-file origin registry ---
// Remembers which bin/folder an offline item came from, so a later "Restore
// Offline Files" pass can put it back once it's relinked. Stored as plain
// tab-separated lines (id, originalPath) rather than JSON, because
// ExtendScript's engine doesn't reliably provide a built-in JSON object.
// Global (not project-scoped) for both apps: unlike folder NAMES (which
// easily collide between unrelated projects, e.g. two projects both having
// a "Main Edit"), the id keying this registry (Premiere's nodeId, AE's
// Item.id) is unique enough that a global file is safe.
function readKeyValueFile(path) {
    var registry = {};
    try {
        var f = new File(path);
        if (f.exists) {
            f.open('r');
            var content = f.read();
            f.close();
            var lines = content.split('\n');
            for (var i = 0; i < lines.length; i++) {
                var line = lines[i].replace(/\r$/, '');
                if (!line) continue;
                var tabIndex = line.indexOf('\t');
                if (tabIndex === -1) continue;
                registry[line.substring(0, tabIndex)] = line.substring(tabIndex + 1);
            }
        }
    } catch (e) {}
    return registry;
}

function writeKeyValueFile(path, registry) {
    try {
        var lines = [];
        for (var key in registry) {
            if (registry.hasOwnProperty(key)) lines.push(key + '\t' + registry[key]);
        }
        var folder = new Folder($.getenv('APPDATA') + '/Adobe/CEP');
        if (!folder.exists) folder.create();
        var f = new File(path);
        f.open('w');
        f.write(lines.join('\n'));
        f.close();
    } catch (e) {}
}

function getRegistryPath() {
    return $.getenv('APPDATA') + '/Adobe/CEP/MediaLibraryOfflineOrigins.txt';
}
function readOfflineRegistry() { return readKeyValueFile(getRegistryPath()); }
function writeOfflineRegistry(registry) { writeKeyValueFile(getRegistryPath(), registry); }

function getAEOfflineRegistryPath() {
    return $.getenv('APPDATA') + '/Adobe/CEP/MediaLibraryAEOfflineOrigins.txt';
}
function aeReadOfflineRegistry() { return readKeyValueFile(getAEOfflineRegistryPath()); }
function aeWriteOfflineRegistry(registry) { writeKeyValueFile(getAEOfflineRegistryPath(), registry); }

// --- Sequence-folder name registry ---
// Remembers every folder name Per-Sequence organizing has created for a
// TOP-LEVEL sequence (e.g. "MyEdit"), so that a later cleanup pass can tell
// "an empty folder we created for a sequence" apart from "a user's own
// empty folder that happens to share a name" - unlike the fixed
// MANAGED_BIN_NAMES, sequence names are arbitrary and could coincidentally
// match something the user made on purpose, so this can't be a fixed list.
// Scoped to the current project file (stored as a sidecar next to it)
// rather than one shared/global file, since two unrelated projects could
// easily have same-named sequences and we don't want project A's cleanup
// deleting an unrelated empty folder in project B.
function getSequenceFolderRegistryPath() {
    try {
        var projectPath = app.project.path;
        if (projectPath) return projectPath + '.medialibrary-seqfolders.txt';
    } catch (e) {}
    // Unsaved project has no path yet - fall back to a generic shared file.
    return $.getenv('APPDATA') + '/Adobe/CEP/MediaLibrarySequenceFolders_untitled.txt';
}

// Generic "set of names, one per line" file - shared by the Premiere
// sequence-folder registry and the AE comp-folder registry below.
function readNameSetFile(path) {
    var names = {};
    try {
        var f = new File(path);
        if (f.exists) {
            f.open('r');
            var content = f.read();
            f.close();
            var lines = content.split('\n');
            for (var i = 0; i < lines.length; i++) {
                var line = lines[i].replace(/\r$/, '');
                if (line) names[line] = true;
            }
        }
    } catch (e) {}
    return names;
}

function writeNameSetFile(path, names) {
    try {
        var lines = [];
        for (var name in names) {
            if (names.hasOwnProperty(name)) lines.push(name);
        }
        var f = new File(path);
        f.open('w');
        f.write(lines.join('\n'));
        f.close();
    } catch (e) {}
}

function readSequenceFolderRegistry() { return readNameSetFile(getSequenceFolderRegistryPath()); }
function writeSequenceFolderRegistry(names) { writeNameSetFile(getSequenceFolderRegistryPath(), names); }

// AE equivalent, scoped to the current project the same way and for the
// same reason (two unrelated projects could have same-named comps).
function getCompFolderRegistryPath() {
    try {
        var projectFile = app.project.file;
        if (projectFile) return projectFile.fsName + '.medialibrary-compfolders.txt';
    } catch (e) {}
    return $.getenv('APPDATA') + '/Adobe/CEP/MediaLibraryCompFolders_untitled.txt';
}

function aeReadCompFolderRegistry() { return readNameSetFile(getCompFolderRegistryPath()); }
function aeWriteCompFolderRegistry(names) { writeNameSetFile(getCompFolderRegistryPath(), names); }

// Recursively removes empty bins we recognize as our own - either a fixed
// managed name (Video Library, Unused, etc.) or a name recorded in the
// sequence-folder registry. Bottom-up, so a bin that only becomes empty
// after its own children get cleaned up (e.g. "MyEdit" once its "Video
// Library" sub-bin is removed) is still caught in the same pass. Returns
// how many bins were actually removed; if the ExtendScript engine doesn't
// expose a way to delete a bin, this quietly does nothing.
function cleanupEmptyManagedBins(bin, extraNames) {
    var removed = 0;
    var children = [];
    for (var i = 0; i < bin.children.numItems; i++) children.push(bin.children[i]);

    for (var j = 0; j < children.length; j++) {
        var child = children[j];
        if (child.type !== ProjectItemType.BIN) continue;
        removed += cleanupEmptyManagedBins(child, extraNames);
        var isOurs = MANAGED_BIN_NAMES.hasOwnProperty(child.name) ||
            (extraNames && extraNames.hasOwnProperty(child.name));
        if (isOurs && child.children.numItems === 0) {
            try {
                if (typeof child.deleteBin === 'function') {
                    child.deleteBin();
                    removed++;
                }
            } catch (e) {}
        }
    }
    return removed;
}

// --- Whole-project organizer (Premiere only) ---

// Single pass over every sequence's tracks, collecting which project items
// are referenced by a clip anywhere in the project. Used for two things:
// - a sequence referenced by another sequence's clip is a "nest"
// - a footage item referenced by no clip anywhere is "unused"
function buildUsedItemIds(project) {
    var usedIds = {};
    var seqCount = project.sequences.numSequences;
    for (var s = 0; s < seqCount; s++) {
        var seq = project.sequences[s];
        markUsage(seq.videoTracks, usedIds);
        markUsage(seq.audioTracks, usedIds);
    }
    return usedIds;
}

function markUsage(trackGroup, usedIds) {
    try {
        for (var t = 0; t < trackGroup.numTracks; t++) {
            var track = trackGroup[t];
            for (var c = 0; c < track.clips.numItems; c++) {
                try {
                    var pi = track.clips[c].projectItem;
                    if (pi && pi.nodeId) usedIds[pi.nodeId] = true;
                } catch (e) {}
            }
        }
    } catch (e) {}
}

// Per-sequence version of buildUsedItemIds/markUsage: returns
// { sequenceNodeId: { itemNodeId: true, ... } } - which items each
// individual sequence directly references. Needed for per-sequence
// organizing, where "used by exactly one sequence" vs "used by several"
// determines whether a file goes into that sequence's own folder or into
// Shared Files.
function buildPerSequenceUsage(project) {
    var usage = {};
    var seqCount = project.sequences.numSequences;
    for (var s = 0; s < seqCount; s++) {
        var seq = project.sequences[s];
        var seqId = seq.projectItem.nodeId;
        usage[seqId] = {};
        markUsage(seq.videoTracks, usage[seqId]);
        markUsage(seq.audioTracks, usage[seqId]);
    }
    return usage;
}

// Audio shorter than MUSIC_MIN_SECONDS is treated as SFX, longer as music.
// If the duration can't be read for some reason, default to SFX (the safer/
// shorter bucket) rather than guessing it's a full music track.
function getDurationSeconds(item) {
    try {
        var out = item.getOutPoint();
        if (out && typeof out.seconds !== 'undefined') {
            var seconds = parseFloat(out.seconds);
            if (!isNaN(seconds)) return seconds;
        }
    } catch (e) {}
    return null;
}

// Walks the whole bin tree once and returns a flat list of
// { item: ProjectItem, parentPath: string } for every non-bin item, where
// parentPath is the "/"-joined chain of bin names from root down to (but not
// including) the item itself - "" means the item sits directly under root.
function collectAllItems(bin, parentPath, out) {
    for (var i = 0; i < bin.children.numItems; i++) {
        var child = bin.children[i];
        if (child.type === ProjectItemType.BIN) {
            var childPath = parentPath ? (parentPath + '/' + child.name) : child.name;
            collectAllItems(child, childPath, out);
        } else {
            out.push({ item: child, parentPath: parentPath });
        }
    }
}

function organizeProjectImpl() {
    var project = app.project;
    var root = project.rootItem;

    var sequenceIds = {};
    var seqCount = project.sequences.numSequences;
    for (var s = 0; s < seqCount; s++) {
        sequenceIds[project.sequences[s].projectItem.nodeId] = true;
    }
    var usedIds = buildUsedItemIds(project);

    var flat = [];
    collectAllItems(root, '', flat);

    var counts = { video: 0, audio: 0, music: 0, image: 0, solid: 0, sequence: 0, nest: 0,
        mogrt: 0, linkedComp: 0, subtitle: 0, offline: 0, unused: 0, skipped: 0, errors: 0,
        project: 0, font: 0, c3d: 0, lut: 0, script: 0, vector: 0, data: 0, preset: 0 };
    var binCache = {};
    function getBin(name) {
        if (!binCache[name]) binCache[name] = ppGetOrCreateBin(root, name);
        return binCache[name];
    }

    var offlineRegistry = readOfflineRegistry();
    var registryChanged = false;

    for (var f = 0; f < flat.length; f++) {
        var entry = flat[f];
        var item = entry.item;
        // "Already organized" means the immediate parent bin is one the user
        // named themselves (e.g. "Camera 1") - not one of our own managed
        // library folders, even if a prior organize run (in either mode)
        // nested it somewhere other than root (e.g. "MyEdit/Video Library").
        var canReorganize = isManagedLocation(entry.parentPath);
        try {
            var targetBinName = null;
            var countKey = null;

            if (sequenceIds[item.nodeId]) {
                // A sequence used as a clip inside another sequence is a nest.
                if (usedIds[item.nodeId]) {
                    targetBinName = 'Nests';
                    countKey = 'nest';
                } else {
                    targetBinName = 'Sequences';
                    countKey = 'sequence';
                }
            } else {
                var offline = false;
                try { offline = item.isOffline ? item.isOffline() : false; } catch (e) { offline = false; }

                if (offline) {
                    // Offline files are always surfaced regardless of where they
                    // currently live, so a relink later has something to restore
                    // them from - remember their current bin, unless we've
                    // already recorded an origin for this item from a past run.
                    if (entry.parentPath !== 'Offline' && !offlineRegistry.hasOwnProperty(item.nodeId)) {
                        offlineRegistry[item.nodeId] = entry.parentPath;
                        registryChanged = true;
                    }
                    targetBinName = 'Offline';
                    countKey = 'offline';
                } else {
                    var mediaPath = '';
                    try { mediaPath = item.getMediaPath ? item.getMediaPath() : ''; } catch (e) { mediaPath = ''; }

                    if (!mediaPath) {
                        // No real file on disk: adjustment layer, color matte,
                        // bars & tone, black video, counting leader, etc.
                        targetBinName = 'Solids';
                        countKey = 'solid';
                    } else {
                        var ext = extOf(mediaPath);
                        if (ext === '.aep') {
                            targetBinName = 'Linked Comps';
                            countKey = 'linkedComp';
                        } else if (ext === '.mogrt') {
                            targetBinName = 'Motion Graphics Templates';
                            countKey = 'mogrt';
                        } else if (arrayContains(SUBTITLE_EXTS, ext)) {
                            // Always corralled, not usage-gated like video/audio/
                            // image: captions sit on a different track type than
                            // regular clips, and it's not verified that their
                            // underlying project item is reachable the same way
                            // through track.clips[].projectItem, so this avoids
                            // risking a caption file wrongly landing in Unused.
                            targetBinName = 'Subtitles';
                            countKey = 'subtitle';
                        } else if (arrayContains(VIDEO_EXTS, ext)) {
                            if (!canReorganize) { counts.skipped++; continue; }
                            if (!usedIds[item.nodeId]) {
                                targetBinName = 'Unused';
                                countKey = 'unused';
                            } else {
                                targetBinName = 'Video Library';
                                countKey = 'video';
                            }
                        } else if (arrayContains(AUDIO_EXTS, ext)) {
                            if (!canReorganize) { counts.skipped++; continue; }
                            if (!usedIds[item.nodeId]) {
                                targetBinName = 'Unused';
                                countKey = 'unused';
                            } else {
                                var durationSeconds = getDurationSeconds(item);
                                if (durationSeconds !== null && durationSeconds >= MUSIC_MIN_SECONDS) {
                                    targetBinName = 'Music Library';
                                    countKey = 'music';
                                } else {
                                    targetBinName = 'SFX Library';
                                    countKey = 'audio';
                                }
                            }
                        } else if (arrayContains(IMAGE_EXTS, ext)) {
                            if (!canReorganize) { counts.skipped++; continue; }
                            if (!usedIds[item.nodeId]) {
                                targetBinName = 'Unused';
                                countKey = 'unused';
                            } else {
                                targetBinName = 'Images Library';
                                countKey = 'image';
                            }
                        } else if (arrayContains(PROJECT_EXTS, ext)) {
                            targetBinName = 'Projects';
                            countKey = 'project';
                        } else if (arrayContains(FONT_EXTS, ext)) {
                            targetBinName = 'Fonts';
                            countKey = 'font';
                        } else if (arrayContains(C3D_EXTS, ext)) {
                            targetBinName = '3D';
                            countKey = 'c3d';
                        } else if (arrayContains(LUT_EXTS, ext)) {
                            targetBinName = 'LUTs';
                            countKey = 'lut';
                        } else if (arrayContains(SCRIPT_EXTS, ext)) {
                            targetBinName = 'Scripts';
                            countKey = 'script';
                        } else if (arrayContains(VECTOR_EXTS, ext)) {
                            targetBinName = 'Vectors';
                            countKey = 'vector';
                        } else if (arrayContains(DATA_EXTS, ext)) {
                            targetBinName = 'Data';
                            countKey = 'data';
                        } else if (arrayContains(PRESET_EXTS, ext)) {
                            targetBinName = 'Presets';
                            countKey = 'preset';
                        } else {
                            // Unrecognized file type - leave as-is
                            continue;
                        }
                    }
                }
            }

            var targetBin = getBin(targetBinName);
            item.moveBin(targetBin);
            counts[countKey]++;
        } catch (e) {
            counts.errors++;
        }
    }

    if (registryChanged) writeOfflineRegistry(offlineRegistry);

    // Clean up any now-empty leftover scaffolding, e.g. from a prior
    // Per-Sequence run whose contents just got flattened back out.
    var removedFolders = cleanupEmptyManagedBins(root, readSequenceFolderRegistry());

    return 'Organized: ' + counts.video + ' videos, ' + counts.audio + ' SFX, ' + counts.music + ' music, ' +
        counts.image + ' images, ' + counts.solid + ' solids, ' + counts.sequence + ' sequences, ' +
        counts.nest + ' nests, ' + counts.mogrt + ' MOGRTs, ' + counts.linkedComp + ' linked comps, ' +
        counts.subtitle + ' subtitles, ' + counts.project + ' projects, ' + counts.font + ' fonts, ' +
        counts.c3d + ' 3D, ' + counts.lut + ' LUTs, ' + counts.script + ' scripts, ' +
        counts.vector + ' vectors, ' + counts.data + ' data, ' + counts.preset + ' presets, ' +
        counts.offline + ' offline, ' + counts.unused +
        ' unused. Left in place: ' + counts.skipped +
        (counts.errors ? ('. Errors: ' + counts.errors) : '') +
        (removedFolders ? ('. Removed ' + removedFolders + ' empty leftover folder' + (removedFolders === 1 ? '' : 's') + '.') : '');
}

// After Effects flat organizer. Same overall shape as organizeProjectImpl,
// adapted to AE's model: Compositions instead of Sequences, Nested Comps
// instead of Nests, and genuine Solid-color footage items instead of the
// "no media path" inference Premiere needed (AE distinguishes SolidSource
// explicitly). Motion Graphics Templates and Linked Comps don't really
// apply inside AE's own project panel, so those categories are skipped here.
function aeOrganizeProjectImpl() {
    var project = app.project;
    var usedIds = aeBuildUsedItemIds(project);

    var counts = { video: 0, audio: 0, music: 0, image: 0, solid: 0, comp: 0, nestedComp: 0,
        subtitle: 0, offline: 0, unused: 0, skipped: 0, errors: 0,
        project: 0, font: 0, c3d: 0, lut: 0, script: 0, vector: 0, data: 0, preset: 0 };
    var folderCache = {};
    function getFolder(name) {
        if (!folderCache[name]) folderCache[name] = aeGetOrCreateFolder(project, name, project.rootFolder);
        return folderCache[name];
    }

    var offlineRegistry = aeReadOfflineRegistry();
    var offlineRegistryChanged = false;

    // Snapshot first: project.numItems/project.item(i) is a live view, and
    // moving items around (or creating new folders) while iterating it can
    // skip or duplicate entries.
    var items = [];
    for (var i = 1; i <= project.numItems; i++) items.push(project.item(i));

    for (var n = 0; n < items.length; n++) {
        var item = items[n];
        if (item instanceof FolderItem) continue;

        var folderPath = aeGetFolderPath(item);
        var canReorganize = isManagedLocation(folderPath);

        try {
            var targetFolderName = null;
            var countKey = null;

            if (item instanceof CompItem) {
                // A comp used as a layer inside another comp is a nested comp.
                if (usedIds[item.id]) {
                    targetFolderName = 'Nested Comps';
                    countKey = 'nestedComp';
                } else {
                    targetFolderName = 'Comps';
                    countKey = 'comp';
                }
            } else if (item instanceof FootageItem) {
                if (item.footageMissing) {
                    // Offline files are always surfaced regardless of where
                    // they currently live, so a relink later has something
                    // to restore them from - remember their current folder,
                    // unless we've already recorded an origin for this item
                    // from a past run.
                    var itemIdKey = String(item.id);
                    if (folderPath !== 'Offline' && !offlineRegistry.hasOwnProperty(itemIdKey)) {
                        offlineRegistry[itemIdKey] = folderPath;
                        offlineRegistryChanged = true;
                    }
                    targetFolderName = 'Offline';
                    countKey = 'offline';
                } else if (item.mainSource instanceof SolidSource) {
                    targetFolderName = 'Solids';
                    countKey = 'solid';
                } else if (item.mainSource instanceof FileSource && item.mainSource.file) {
                    var ext = extOf(item.mainSource.file.fsName);
                    if (arrayContains(SUBTITLE_EXTS, ext)) {
                        targetFolderName = 'Subtitles';
                        countKey = 'subtitle';
                    } else if (arrayContains(VIDEO_EXTS, ext)) {
                        if (!canReorganize) { counts.skipped++; continue; }
                        if (!usedIds[item.id]) {
                            targetFolderName = 'Unused';
                            countKey = 'unused';
                        } else {
                            targetFolderName = 'Video Library';
                            countKey = 'video';
                        }
                    } else if (arrayContains(AUDIO_EXTS, ext)) {
                        if (!canReorganize) { counts.skipped++; continue; }
                        if (!usedIds[item.id]) {
                            targetFolderName = 'Unused';
                            countKey = 'unused';
                        } else {
                            var durationSeconds = aeGetDurationSeconds(item);
                            if (durationSeconds !== null && durationSeconds >= MUSIC_MIN_SECONDS) {
                                targetFolderName = 'Music Library';
                                countKey = 'music';
                            } else {
                                targetFolderName = 'SFX Library';
                                countKey = 'audio';
                            }
                        }
                    } else if (arrayContains(IMAGE_EXTS, ext)) {
                        if (!canReorganize) { counts.skipped++; continue; }
                        if (!usedIds[item.id]) {
                            targetFolderName = 'Unused';
                            countKey = 'unused';
                        } else {
                            targetFolderName = 'Images Library';
                            countKey = 'image';
                        }
                    } else if (arrayContains(PROJECT_EXTS, ext)) {
                        targetFolderName = 'Projects';
                        countKey = 'project';
                    } else if (arrayContains(FONT_EXTS, ext)) {
                        targetFolderName = 'Fonts';
                        countKey = 'font';
                    } else if (arrayContains(C3D_EXTS, ext)) {
                        targetFolderName = '3D';
                        countKey = 'c3d';
                    } else if (arrayContains(LUT_EXTS, ext)) {
                        targetFolderName = 'LUTs';
                        countKey = 'lut';
                    } else if (arrayContains(SCRIPT_EXTS, ext)) {
                        targetFolderName = 'Scripts';
                        countKey = 'script';
                    } else if (arrayContains(VECTOR_EXTS, ext)) {
                        targetFolderName = 'Vectors';
                        countKey = 'vector';
                    } else if (arrayContains(DATA_EXTS, ext)) {
                        targetFolderName = 'Data';
                        countKey = 'data';
                    } else if (arrayContains(PRESET_EXTS, ext)) {
                        targetFolderName = 'Presets';
                        countKey = 'preset';
                    } else {
                        continue; // Unrecognized file type - leave as-is
                    }
                } else {
                    continue; // e.g. a placeholder - leave as-is
                }
            } else {
                continue;
            }

            item.parentFolder = getFolder(targetFolderName);
            counts[countKey]++;
        } catch (e) {
            counts.errors++;
        }
    }

    if (offlineRegistryChanged) aeWriteOfflineRegistry(offlineRegistry);

    var removedFolders = aeCleanupEmptyManagedBins(project, aeReadCompFolderRegistry());

    return 'Organized: ' + counts.video + ' videos, ' + counts.audio + ' SFX, ' + counts.music + ' music, ' +
        counts.image + ' images, ' + counts.solid + ' solids, ' + counts.comp + ' comps, ' +
        counts.nestedComp + ' nested comps, ' + counts.subtitle + ' subtitles, ' +
        counts.project + ' projects, ' + counts.font + ' fonts, ' +
        counts.c3d + ' 3D, ' + counts.lut + ' LUTs, ' + counts.script + ' scripts, ' +
        counts.vector + ' vectors, ' + counts.data + ' data, ' + counts.preset + ' presets, ' +
        counts.offline + ' offline, ' + counts.unused + ' unused. Left in place: ' + counts.skipped +
        (counts.errors ? ('. Errors: ' + counts.errors) : '') +
        (removedFolders ? ('. Removed ' + removedFolders + ' empty leftover folder' + (removedFolders === 1 ? '' : 's') + '.') : '');
}

// AE's per-composition organizer, mirroring organizeProjectBySequenceImpl:
// each TOP-LEVEL comp (one not itself used as a layer in another comp) gets
// its own root-level folder with the same sub-library structure as flat
// mode, for files it uses exclusively. Files used by 2+ comps go into
// "Shared Files" instead of being duplicated. Subtitles stay flat/global
// (not per-comp) for the same reason as flat mode - consistency, and .srt-
// type footage in AE's own project panel is rare enough that per-comp
// resolution isn't worth the complexity. Like Premiere's per-sequence mode,
// this reorganizes everything regardless of current location, since it's
// regrouping by a different axis than any prior manual sort.
function aeOrganizeProjectByCompImpl() {
    var project = app.project;

    var compIds = {};
    var compNameById = {};
    for (var i = 1; i <= project.numItems; i++) {
        var it = project.item(i);
        if (it instanceof CompItem) {
            compIds[it.id] = true;
            compNameById[it.id] = it.name;
        }
    }

    var perCompUsage = aeBuildPerCompUsage(project);

    var usedAnywhere = {};
    for (var cid in perCompUsage) {
        if (!perCompUsage.hasOwnProperty(cid)) continue;
        for (var iid in perCompUsage[cid]) {
            if (perCompUsage[cid].hasOwnProperty(iid)) usedAnywhere[iid] = true;
        }
    }
    var isNested = {};
    for (var cid2 in compIds) {
        if (compIds.hasOwnProperty(cid2)) isNested[cid2] = !!usedAnywhere[cid2];
    }

    // Resolves which TOP-LEVEL comp(s) an item ultimately belongs to,
    // following through precomps transitively. Memoized; guards against
    // cycles defensively (AE shouldn't allow a comp to nest itself, but
    // just in case).
    var resolveMemo = {};
    var resolveVisiting = {};
    function resolveTopLevelUsers(itemId) {
        if (resolveMemo.hasOwnProperty(itemId)) return resolveMemo[itemId];
        if (resolveVisiting[itemId]) return {};
        resolveVisiting[itemId] = true;
        var result = {};
        for (var cid3 in perCompUsage) {
            if (!perCompUsage.hasOwnProperty(cid3)) continue;
            if (!perCompUsage[cid3][itemId]) continue;
            if (isNested[cid3]) {
                var upstream = resolveTopLevelUsers(cid3);
                for (var k in upstream) { if (upstream.hasOwnProperty(k)) result[k] = true; }
            } else {
                result[cid3] = true;
            }
        }
        resolveVisiting[itemId] = false;
        resolveMemo[itemId] = result;
        return result;
    }

    // Disambiguate folder names up front - AE allows duplicate comp names,
    // and a comp could coincidentally be named the same as a reserved folder.
    var usedNames = { 'Shared Files': true, 'Unused': true, 'Offline': true, 'Subtitles': true };
    var folderNameById = {};
    var topLevelCount = 0;
    for (var cid4 in compIds) {
        if (!compIds.hasOwnProperty(cid4) || isNested[cid4]) continue;
        topLevelCount++;
        var baseName = compNameById[cid4];
        var candidate = baseName;
        var n = 2;
        while (usedNames.hasOwnProperty(candidate)) {
            candidate = baseName + ' (' + n + ')';
            n++;
        }
        usedNames[candidate] = true;
        folderNameById[cid4] = candidate;
    }

    // Remember every comp-folder name this run creates, so a later Flat (or
    // future Per-Comp) run's cleanup pass can recognize an empty one as
    // ours to remove.
    var compFolderRegistry = aeReadCompFolderRegistry();
    var compFolderRegistryChanged = false;
    for (var cid5 in folderNameById) {
        if (!folderNameById.hasOwnProperty(cid5)) continue;
        var fname = folderNameById[cid5];
        if (!compFolderRegistry.hasOwnProperty(fname)) {
            compFolderRegistry[fname] = true;
            compFolderRegistryChanged = true;
        }
    }
    if (compFolderRegistryChanged) aeWriteCompFolderRegistry(compFolderRegistry);

    var counts = { video: 0, audio: 0, music: 0, image: 0, solid: 0, subtitle: 0, comp: 0,
        nestedComp: 0, offline: 0, unused: 0, shared: 0, skipped: 0, errors: 0,
        project: 0, font: 0, c3d: 0, lut: 0, script: 0, vector: 0, data: 0, preset: 0 };

    var folderCache = {};
    function getTopFolder(name) {
        if (!folderCache[name]) folderCache[name] = aeGetOrCreateFolder(project, name, project.rootFolder);
        return folderCache[name];
    }
    function getSubFolder(ownerName, subName) {
        var key = ownerName + '||' + subName;
        if (!folderCache.hasOwnProperty(key)) {
            folderCache[key] = aeGetOrCreateFolder(project, subName, getTopFolder(ownerName));
        }
        return folderCache[key];
    }

    var offlineRegistry = aeReadOfflineRegistry();
    var offlineRegistryChanged = false;

    // Snapshot first, same reason as aeOrganizeProjectImpl.
    var items = [];
    for (var n2 = 1; n2 <= project.numItems; n2++) items.push(project.item(n2));

    for (var f = 0; f < items.length; f++) {
        var item = items[f];
        if (item instanceof FolderItem) continue;

        try {
            if (item instanceof CompItem) {
                if (isNested[item.id]) {
                    var nestOwners = resolveTopLevelUsers(item.id);
                    var nestOwnerIds = [];
                    for (var nok in nestOwners) { if (nestOwners.hasOwnProperty(nok)) nestOwnerIds.push(nok); }
                    var nestTarget;
                    if (nestOwnerIds.length === 1) {
                        nestTarget = getSubFolder(folderNameById[nestOwnerIds[0]], 'Nested Comps');
                    } else {
                        nestTarget = getSubFolder('Shared Files', 'Nested Comps');
                        if (nestOwnerIds.length >= 2) counts.shared++;
                    }
                    item.parentFolder = nestTarget;
                    counts.nestedComp++;
                } else {
                    item.parentFolder = getTopFolder(folderNameById[item.id]);
                    counts.comp++;
                }
                continue;
            }

            if (!(item instanceof FootageItem)) continue;

            if (item.footageMissing) {
                var folderPath = aeGetFolderPath(item);
                var itemIdKey = String(item.id);
                if (folderPath !== 'Offline' && !offlineRegistry.hasOwnProperty(itemIdKey)) {
                    offlineRegistry[itemIdKey] = folderPath;
                    offlineRegistryChanged = true;
                }
                item.parentFolder = getTopFolder('Offline');
                counts.offline++;
                continue;
            }

            var subName = null;
            var countKey = null;

            if (item.mainSource instanceof SolidSource) {
                subName = 'Solids';
                countKey = 'solid';
            } else if (item.mainSource instanceof FileSource && item.mainSource.file) {
                var ext = extOf(item.mainSource.file.fsName);
                if (arrayContains(SUBTITLE_EXTS, ext)) {
                    item.parentFolder = getTopFolder('Subtitles');
                    counts.subtitle++;
                    continue;
                } else if (arrayContains(VIDEO_EXTS, ext)) {
                    subName = 'Video Library';
                    countKey = 'video';
                } else if (arrayContains(AUDIO_EXTS, ext)) {
                    var durationSeconds = aeGetDurationSeconds(item);
                    if (durationSeconds !== null && durationSeconds >= MUSIC_MIN_SECONDS) {
                        subName = 'Music Library';
                        countKey = 'music';
                    } else {
                        subName = 'SFX Library';
                        countKey = 'audio';
                    }
                } else if (arrayContains(IMAGE_EXTS, ext)) {
                    subName = 'Images Library';
                    countKey = 'image';
                } else if (arrayContains(PROJECT_EXTS, ext)) {
                    item.parentFolder = getTopFolder('Projects');
                    counts.project++;
                    continue;
                } else if (arrayContains(FONT_EXTS, ext)) {
                    item.parentFolder = getTopFolder('Fonts');
                    counts.font++;
                    continue;
                } else if (arrayContains(C3D_EXTS, ext)) {
                    item.parentFolder = getTopFolder('3D');
                    counts.c3d++;
                    continue;
                } else if (arrayContains(LUT_EXTS, ext)) {
                    item.parentFolder = getTopFolder('LUTs');
                    counts.lut++;
                    continue;
                } else if (arrayContains(SCRIPT_EXTS, ext)) {
                    item.parentFolder = getTopFolder('Scripts');
                    counts.script++;
                    continue;
                } else if (arrayContains(VECTOR_EXTS, ext)) {
                    item.parentFolder = getTopFolder('Vectors');
                    counts.vector++;
                    continue;
                } else if (arrayContains(DATA_EXTS, ext)) {
                    item.parentFolder = getTopFolder('Data');
                    counts.data++;
                    continue;
                } else if (arrayContains(PRESET_EXTS, ext)) {
                    item.parentFolder = getTopFolder('Presets');
                    counts.preset++;
                    continue;
                } else {
                    counts.skipped++;
                    continue;
                }
            } else {
                counts.skipped++;
                continue;
            }

            var owners = resolveTopLevelUsers(item.id);
            var ownerIds = [];
            for (var ok in owners) { if (owners.hasOwnProperty(ok)) ownerIds.push(ok); }

            var target;
            if (ownerIds.length === 0) {
                target = getTopFolder('Unused');
                countKey = 'unused';
            } else if (ownerIds.length === 1) {
                target = getSubFolder(folderNameById[ownerIds[0]], subName);
            } else {
                target = getSubFolder('Shared Files', subName);
                counts.shared++;
            }

            item.parentFolder = target;
            counts[countKey]++;
        } catch (e) {
            counts.errors++;
        }
    }

    if (offlineRegistryChanged) aeWriteOfflineRegistry(offlineRegistry);

    var removedFolders = aeCleanupEmptyManagedBins(project, compFolderRegistry);

    return 'Organized by comp: ' + topLevelCount + ' comp folders, ' + counts.shared +
        ' items shared across comps. ' + counts.video + ' videos, ' + counts.audio + ' SFX, ' +
        counts.music + ' music, ' + counts.image + ' images, ' + counts.solid + ' solids, ' +
        counts.subtitle + ' subtitles (flat, not per-comp), ' + counts.nestedComp + ' nested comps, ' +
        counts.project + ' projects, ' + counts.font + ' fonts, ' +
        counts.c3d + ' 3D, ' + counts.lut + ' LUTs, ' + counts.script + ' scripts, ' +
        counts.vector + ' vectors, ' + counts.data + ' data, ' + counts.preset + ' presets, ' +
        counts.offline + ' offline, ' + counts.unused + ' unused' +
        (counts.skipped ? ('. Left in place: ' + counts.skipped) : '') +
        (counts.errors ? ('. Errors: ' + counts.errors) : '') +
        (removedFolders ? ('. Removed ' + removedFolders + ' empty leftover folder' + (removedFolders === 1 ? '' : 's') + '.') : '');
}

function aeFolderDepth(folder) {
    var depth = 0;
    var f = folder.parentFolder;
    while (f) { depth++; f = f.parentFolder; }
    return depth;
}

// Removes empty folders we recognize as our own - either a fixed managed
// name (Video Library, Unused, etc.) or a name recorded in extraNames (e.g.
// the AE comp-folder registry). Same idea as cleanupEmptyManagedBins for
// Premiere; processes deepest folders first so a folder that only becomes
// empty once its own (now-removed) child is gone still gets caught in this
// same pass, rather than needing a second run. AE's Item.remove() is a
// well-established scripting method (unlike Premiere's ProjectItem, whose
// support for deleting a bin via script was genuinely uncertain until we
// tested it), so this is on firmer footing than its Premiere counterpart.
function aeCleanupEmptyManagedBins(project, extraNames) {
    var removed = 0;
    var folders = [];
    for (var i = 1; i <= project.numItems; i++) {
        var item = project.item(i);
        if (item instanceof FolderItem) {
            var isOurs = MANAGED_BIN_NAMES.hasOwnProperty(item.name) ||
                (extraNames && extraNames.hasOwnProperty(item.name));
            if (isOurs) folders.push(item);
        }
    }
    folders.sort(function(a, b) { return aeFolderDepth(b) - aeFolderDepth(a); });
    for (var f = 0; f < folders.length; f++) {
        var folder = folders[f];
        try {
            if (folder.numItems === 0) {
                folder.remove();
                removed++;
            }
        } catch (e) {}
    }
    return removed;
}

// Per-sequence organizer: each top-level sequence (one not itself nested
// inside another sequence) gets its own root-level folder containing the
// same sub-library structure as flat mode, but only for files used
// exclusively by that sequence. Files used by 2+ sequences go into a
// "Shared Files" folder with the same sub-library structure instead of
// being duplicated. Files used by none go into "Unused". Offline files
// always go into "Offline" regardless of mode, same as flat organizing.
//
// Unlike flat mode, this reorganizes EVERYTHING - including video/audio/
// image files you already filed manually - because the whole point is
// regrouping by which sequence uses each file, a different axis than
// whatever manual grouping (e.g. by camera) existed before.
function organizeProjectBySequenceImpl() {
    var project = app.project;
    var root = project.rootItem;

    var sequenceIds = {};
    var seqNameById = {};
    var seqCount = project.sequences.numSequences;
    for (var s = 0; s < seqCount; s++) {
        var spi = project.sequences[s].projectItem;
        sequenceIds[spi.nodeId] = true;
        seqNameById[spi.nodeId] = spi.name;
    }

    var perSeqUsage = buildPerSequenceUsage(project);

    // Union of everything referenced by any sequence, used only to tell
    // which sequences are nests (referenced by another sequence's clips).
    var usedAnywhere = {};
    for (var seqId in perSeqUsage) {
        if (!perSeqUsage.hasOwnProperty(seqId)) continue;
        for (var itemId in perSeqUsage[seqId]) {
            if (perSeqUsage[seqId].hasOwnProperty(itemId)) usedAnywhere[itemId] = true;
        }
    }
    var isNest = {};
    for (var seqId2 in sequenceIds) {
        if (sequenceIds.hasOwnProperty(seqId2)) isNest[seqId2] = !!usedAnywhere[seqId2];
    }

    // Resolves which TOP-LEVEL sequence(s) an item ultimately belongs to,
    // following through nests transitively (a clip used only inside a nest
    // that's itself used only inside one outer sequence belongs to that
    // outer sequence). Memoized; guards against cycles defensively (Premiere
    // shouldn't allow a sequence to nest itself, but just in case).
    var resolveMemo = {};
    var resolveVisiting = {};
    function resolveTopLevelUsers(itemId) {
        if (resolveMemo.hasOwnProperty(itemId)) return resolveMemo[itemId];
        if (resolveVisiting[itemId]) return {};
        resolveVisiting[itemId] = true;
        var result = {};
        for (var sid in perSeqUsage) {
            if (!perSeqUsage.hasOwnProperty(sid)) continue;
            if (!perSeqUsage[sid][itemId]) continue;
            if (isNest[sid]) {
                var upstream = resolveTopLevelUsers(sid);
                for (var k in upstream) { if (upstream.hasOwnProperty(k)) result[k] = true; }
            } else {
                result[sid] = true;
            }
        }
        resolveVisiting[itemId] = false;
        resolveMemo[itemId] = result;
        return result;
    }

    // Disambiguate folder names up front - Premiere allows duplicate
    // sequence names, and a sequence could coincidentally be named the same
    // as one of the reserved top-level folders.
    var usedNames = { 'Shared Files': true, 'Unused': true, 'Offline': true };
    var folderNameById = {};
    var topLevelCount = 0;
    for (var sid2 in sequenceIds) {
        if (!sequenceIds.hasOwnProperty(sid2) || isNest[sid2]) continue;
        topLevelCount++;
        var baseName = seqNameById[sid2];
        var candidate = baseName;
        var n = 2;
        while (usedNames.hasOwnProperty(candidate)) {
            candidate = baseName + ' (' + n + ')';
            n++;
        }
        usedNames[candidate] = true;
        folderNameById[sid2] = candidate;
    }

    // Remember every sequence-folder name this run creates, so a later Flat
    // (or future Per-Sequence) run's cleanup pass can recognize an empty one
    // as ours to remove, without risking a same-named folder the user made.
    var seqFolderRegistry = readSequenceFolderRegistry();
    var seqFolderRegistryChanged = false;
    for (var sid4 in folderNameById) {
        if (!folderNameById.hasOwnProperty(sid4)) continue;
        var fname = folderNameById[sid4];
        if (!seqFolderRegistry.hasOwnProperty(fname)) {
            seqFolderRegistry[fname] = true;
            seqFolderRegistryChanged = true;
        }
    }
    if (seqFolderRegistryChanged) writeSequenceFolderRegistry(seqFolderRegistry);

    var flat = [];
    collectAllItems(root, '', flat);

    var counts = { video: 0, audio: 0, music: 0, image: 0, solid: 0, sequence: 0, nest: 0,
        mogrt: 0, linkedComp: 0, subtitle: 0, offline: 0, unused: 0, shared: 0, skipped: 0, errors: 0,
        project: 0, font: 0, c3d: 0, lut: 0, script: 0, vector: 0, data: 0, preset: 0 };

    var binCache = {};
    function getTopBin(name) {
        if (!binCache[name]) binCache[name] = ppGetOrCreateBin(root, name);
        return binCache[name];
    }
    function getSubBin(ownerBinName, subName) {
        var key = ownerBinName + '||' + subName;
        if (!binCache.hasOwnProperty(key)) {
            binCache[key] = ppGetOrCreateBin(getTopBin(ownerBinName), subName);
        }
        return binCache[key];
    }

    var offlineRegistry = readOfflineRegistry();
    var registryChanged = false;

    for (var f = 0; f < flat.length; f++) {
        var entry = flat[f];
        var item = entry.item;
        try {
            if (sequenceIds[item.nodeId]) {
                if (isNest[item.nodeId]) {
                    var nestOwners = resolveTopLevelUsers(item.nodeId);
                    var nestOwnerIds = [];
                    for (var nok in nestOwners) { if (nestOwners.hasOwnProperty(nok)) nestOwnerIds.push(nok); }
                    var nestTarget;
                    if (nestOwnerIds.length === 1) {
                        nestTarget = getSubBin(folderNameById[nestOwnerIds[0]], 'Nests');
                    } else {
                        nestTarget = getSubBin('Shared Files', 'Nests');
                        if (nestOwnerIds.length >= 2) counts.shared++;
                    }
                    item.moveBin(nestTarget);
                    counts.nest++;
                } else {
                    // Top-level sequence: lives directly inside its own eponymous folder.
                    item.moveBin(getTopBin(folderNameById[item.nodeId]));
                    counts.sequence++;
                }
                continue;
            }

            // Offline always wins, same as flat mode.
            var offline = false;
            try { offline = item.isOffline ? item.isOffline() : false; } catch (e) { offline = false; }
            if (offline) {
                if (entry.parentPath !== 'Offline' && !offlineRegistry.hasOwnProperty(item.nodeId)) {
                    offlineRegistry[item.nodeId] = entry.parentPath;
                    registryChanged = true;
                }
                item.moveBin(getTopBin('Offline'));
                counts.offline++;
                continue;
            }

            var mediaPath = '';
            try { mediaPath = item.getMediaPath ? item.getMediaPath() : ''; } catch (e) { mediaPath = ''; }

            var subName = null;
            var countKey = null;

            if (!mediaPath) {
                subName = 'Solids';
                countKey = 'solid';
            } else {
                var ext = extOf(mediaPath);
                if (arrayContains(SUBTITLE_EXTS, ext)) {
                    // Flat top-level folder, not per-sequence like the rest of
                    // this function: captions sit on a different track type
                    // than regular clips, and it's not verified that their
                    // underlying project item is reachable the same way
                    // through track.clips[].projectItem for per-sequence
                    // usage resolution, so this sidesteps that uncertainty.
                    item.moveBin(getTopBin('Subtitles'));
                    counts.subtitle++;
                    continue;
                } else if (ext === '.aep') {
                    subName = 'Linked Comps';
                    countKey = 'linkedComp';
                } else if (ext === '.mogrt') {
                    subName = 'Motion Graphics Templates';
                    countKey = 'mogrt';
                } else if (arrayContains(VIDEO_EXTS, ext)) {
                    subName = 'Video Library';
                    countKey = 'video';
                } else if (arrayContains(AUDIO_EXTS, ext)) {
                    var durationSeconds = getDurationSeconds(item);
                    if (durationSeconds !== null && durationSeconds >= MUSIC_MIN_SECONDS) {
                        subName = 'Music Library';
                        countKey = 'music';
                    } else {
                        subName = 'SFX Library';
                        countKey = 'audio';
                    }
                } else if (arrayContains(IMAGE_EXTS, ext)) {
                    subName = 'Images Library';
                    countKey = 'image';
                } else if (arrayContains(PROJECT_EXTS, ext)) {
                    item.moveBin(getTopBin('Projects'));
                    counts.project++;
                    continue;
                } else if (arrayContains(FONT_EXTS, ext)) {
                    item.moveBin(getTopBin('Fonts'));
                    counts.font++;
                    continue;
                } else if (arrayContains(C3D_EXTS, ext)) {
                    item.moveBin(getTopBin('3D'));
                    counts.c3d++;
                    continue;
                } else if (arrayContains(LUT_EXTS, ext)) {
                    item.moveBin(getTopBin('LUTs'));
                    counts.lut++;
                    continue;
                } else if (arrayContains(SCRIPT_EXTS, ext)) {
                    item.moveBin(getTopBin('Scripts'));
                    counts.script++;
                    continue;
                } else if (arrayContains(VECTOR_EXTS, ext)) {
                    item.moveBin(getTopBin('Vectors'));
                    counts.vector++;
                    continue;
                } else if (arrayContains(DATA_EXTS, ext)) {
                    item.moveBin(getTopBin('Data'));
                    counts.data++;
                    continue;
                } else if (arrayContains(PRESET_EXTS, ext)) {
                    item.moveBin(getTopBin('Presets'));
                    counts.preset++;
                    continue;
                } else {
                    // Unrecognized file type - leave as-is
                    counts.skipped++;
                    continue;
                }
            }

            var owners = resolveTopLevelUsers(item.nodeId);
            var ownerIds = [];
            for (var ok in owners) { if (owners.hasOwnProperty(ok)) ownerIds.push(ok); }

            var target;
            if (ownerIds.length === 0) {
                target = getTopBin('Unused');
                countKey = 'unused';
            } else if (ownerIds.length === 1) {
                target = getSubBin(folderNameById[ownerIds[0]], subName);
            } else {
                target = getSubBin('Shared Files', subName);
                counts.shared++;
            }

            item.moveBin(target);
            counts[countKey]++;
        } catch (e) {
            counts.errors++;
        }
    }

    if (registryChanged) writeOfflineRegistry(offlineRegistry);

    // Clean up empty leftovers - e.g. a sequence folder from a run where
    // that sequence has since been renamed or deleted, so its old-named
    // folder is now empty since this run filed everything under the new name.
    var removedFolders = cleanupEmptyManagedBins(root, seqFolderRegistry);

    return 'Organized by sequence: ' + topLevelCount + ' sequence folders, ' + counts.shared +
        ' items shared across sequences. ' + counts.video + ' videos, ' + counts.audio + ' SFX, ' +
        counts.music + ' music, ' + counts.image + ' images, ' + counts.solid + ' solids, ' +
        counts.mogrt + ' MOGRTs, ' + counts.linkedComp + ' linked comps, ' + counts.subtitle +
        ' subtitles (flat, not per-sequence), ' + counts.nest + ' nests, ' +
        counts.project + ' projects, ' + counts.font + ' fonts, ' +
        counts.c3d + ' 3D, ' + counts.lut + ' LUTs, ' + counts.script + ' scripts, ' +
        counts.vector + ' vectors, ' + counts.data + ' data, ' + counts.preset + ' presets, ' +
        counts.offline + ' offline, ' + counts.unused + ' unused' +
        (counts.skipped ? ('. Left in place: ' + counts.skipped) : '') +
        (counts.errors ? ('. Errors: ' + counts.errors) : '') +
        (removedFolders ? ('. Removed ' + removedFolders + ' empty leftover folder' + (removedFolders === 1 ? '' : 's') + '.') : '');
}

function restoreOfflineFilesImpl() {
    var project = app.project;
    var root = project.rootItem;

    var offlineBin = null;
    for (var i = 0; i < root.children.numItems; i++) {
        var child = root.children[i];
        if (child.type === ProjectItemType.BIN && child.name === 'Offline') {
            offlineBin = child;
            break;
        }
    }
    if (!offlineBin) return 'No Offline folder found - nothing to restore.';

    var registry = readOfflineRegistry();
    var registryChanged = false;
    var restored = 0;
    var stillOffline = 0;
    var noOrigin = 0;
    var errors = 0;

    // Snapshot children first since moving items mutates offlineBin.children
    // while we'd still be iterating it.
    var items = [];
    for (var j = 0; j < offlineBin.children.numItems; j++) {
        var it = offlineBin.children[j];
        if (it.type !== ProjectItemType.BIN) items.push(it);
    }

    for (var k = 0; k < items.length; k++) {
        var item = items[k];
        try {
            var offline = false;
            try { offline = item.isOffline ? item.isOffline() : false; } catch (e) { offline = false; }

            if (offline) {
                stillOffline++;
                continue;
            }

            if (!registry.hasOwnProperty(item.nodeId)) {
                noOrigin++;
                continue;
            }

            var originPath = registry[item.nodeId];
            var targetBin = getOrCreateBinPath(root, originPath);
            item.moveBin(targetBin);
            delete registry[item.nodeId];
            registryChanged = true;
            restored++;
        } catch (e) {
            errors++;
        }
    }

    if (registryChanged) writeOfflineRegistry(registry);

    return 'Restored: ' + restored + '. Still offline: ' + stillOffline +
        '. Relinked but no recorded origin (left in Offline): ' + noOrigin +
        (errors ? ('. Errors: ' + errors) : '');
}

// AE equivalent of restoreOfflineFilesImpl.
function aeRestoreOfflineFilesImpl() {
    var project = app.project;

    var offlineFolder = null;
    for (var i = 1; i <= project.numItems; i++) {
        var it = project.item(i);
        if (it instanceof FolderItem && it.name === 'Offline' && it.parentFolder === project.rootFolder) {
            offlineFolder = it;
            break;
        }
    }
    if (!offlineFolder) return 'No Offline folder found - nothing to restore.';

    var registry = aeReadOfflineRegistry();
    var registryChanged = false;
    var restored = 0;
    var stillOffline = 0;
    var noOrigin = 0;
    var errors = 0;

    // Snapshot first, same reason as elsewhere: mutating parentFolder while
    // enumerating project.item(i) could skip or duplicate entries.
    var items = [];
    for (var n = 1; n <= project.numItems; n++) {
        var candidate = project.item(n);
        if (!(candidate instanceof FolderItem) && candidate.parentFolder === offlineFolder) {
            items.push(candidate);
        }
    }

    for (var k = 0; k < items.length; k++) {
        var item = items[k];
        try {
            var offline = false;
            try { offline = (item instanceof FootageItem) ? item.footageMissing : false; } catch (e) { offline = false; }

            if (offline) {
                stillOffline++;
                continue;
            }

            var itemIdKey = String(item.id);
            if (!registry.hasOwnProperty(itemIdKey)) {
                noOrigin++;
                continue;
            }

            var originPath = registry[itemIdKey];
            var targetFolder = aeGetOrCreateFolderPath(project, originPath);
            item.parentFolder = targetFolder;
            delete registry[itemIdKey];
            registryChanged = true;
            restored++;
        } catch (e) {
            errors++;
        }
    }

    if (registryChanged) aeWriteOfflineRegistry(registry);

    return 'Restored: ' + restored + '. Still offline: ' + stillOffline +
        '. Relinked but no recorded origin (left in Offline): ' + noOrigin +
        (errors ? ('. Errors: ' + errors) : '');
}

// --- My Clips: Premiere Pro save selected clip ---
function ppSaveSelectedClip() {
    var project = app.project;
    if (!project) return "Error: No project open";
    var seq = project.activeSequence;
    if (!seq) return "Error: No active sequence";
    var sel = seq.getSelection();
    if (!sel || sel.length === 0) return "Error: No clip selected. Select a clip in the timeline first.";

    var trackItem = sel[0];
    var pi = trackItem.projectItem;
    if (!pi) return "Error: Could not read project item";

    var sourcePath = '';
    try { sourcePath = pi.getMediaPath(); } catch (e) { sourcePath = ''; }
    if (!sourcePath) return "Error: Could not read source file path";

    var clip = {
        v: 1,
        name: '',
        source: sourcePath.replace(/\\/g, '/'),
        sourceName: pi.name,
        type: 'clipInstance',
        host: 'PPRO',
        createdAt: new Date().toString(),
        effects: [],
        transform: {},
        clip: {},
        thumbnail: ''
    };

    // Read in/out points and speed
    try {
        var inPt = trackItem.inPoint;
        var outPt = trackItem.outPoint;
        clip.clip.inPoint = inPt;
        clip.clip.outPoint = outPt;
    } catch (e) {}

    // Read speed
    try {
        var speed = trackItem.getSpeed();
        clip.clip.speed = speed;
    } catch (e) {}

    // Read effects from MGT component (Motion Graphics Template effects)
    try {
        var mgt = trackItem.getMGTComponent();
        if (mgt && mgt.properties) {
            for (var i = 0; i < mgt.properties.numProperties; i++) {
                var prop = mgt.properties.getProperty(i);
                if (prop) {
                    clip.effects.push({
                        matchName: prop.matchName || '',
                        displayName: prop.displayName || '',
                        value: prop.value
                    });
                }
            }
        }
    } catch (e) {}

    // Try to read effects from effect parade via sequence.getEffectTracks()
    // This is limited in Premiere's scripting API, so we capture what we can

    return JSON.stringify(clip);
}

// --- My Clips: After Effects save selected layer ---
function aeSaveSelectedClip() {
    var project = app.project;
    if (!project) return "Error: No project open";
    var comp = project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return "Error: No active composition";

    var selLayers = comp.selectedLayers;
    if (!selLayers || selLayers.length === 0) return "Error: No layer selected. Select a layer in the timeline first.";

    var layer = selLayers[0];
    var sourcePath = '';
    try {
        if (layer.source && layer.source.file) {
            sourcePath = layer.source.file.fsName;
        }
    } catch (e) {}

    if (!sourcePath) return "Error: Could not read source file path (may be a solid or null)";

    var clip = {
        v: 1,
        name: '',
        source: sourcePath.replace(/\\/g, '/'),
        sourceName: layer.source.name,
        type: 'clipInstance',
        host: 'AEFT',
        createdAt: new Date().toString(),
        effects: [],
        transform: {},
        clip: {},
        thumbnail: ''
    };

    // Read transform
    try {
        clip.transform = {
            scale: layer.transform.scale.value,
            position: layer.transform.position.value,
            rotation: layer.transform.rotation.value,
            opacity: layer.transform.opacity.value
        };
    } catch (e) {}

    // Read in/out
    try {
        clip.clip.inPoint = layer.inPoint;
        clip.clip.outPoint = layer.outPoint;
        clip.clip.startTime = layer.startTime;
    } catch (e) {}

    // Read time remap
    try {
        if (layer.timeRemapEnabled) {
            clip.clip.timeRemap = true;
        }
    } catch (e) {}

    // Read effects
    try {
        var effectParade = layer.property("ADBE Effect Parade");
        if (effectParade) {
            for (var i = 1; i <= effectParade.numProperties; i++) {
                var eff = effectParade.property(i);
                if (eff) {
                    var effData = {
                        matchName: eff.matchName || '',
                        displayName: eff.name || '',
                        enabled: eff.enabled,
                        params: {}
                    };
                    // Read effect parameters
                    try {
                        for (var j = 1; j <= eff.numProperties; j++) {
                            var p = eff.property(j);
                            if (p && p.canSetEnabled) {
                                effData.params[p.matchName || p.name] = p.value;
                            }
                        }
                    } catch (e2) {}
                    clip.effects.push(effData);
                }
            }
        }
    } catch (e) {}

    return JSON.stringify(clip);
}

// --- My Clips: Premiere Pro apply clip/preset instance ---
function ppApplyClipInstance(jsonPath) {
    var f = new File(jsonPath);
    if (!f.exists) return "Error: Clip file not found";
    f.open('r');
    var content = f.read();
    f.close();
    var clip = JSON.parse(content);

    var project = app.project;
    if (!project) return "Error: No project open";
    var seq = app.project.activeSequence;
    if (!seq) return "Error: No active sequence. Open a sequence first.";

    // Preset-only: apply effects to selected clip, no file import
    if (clip.saveType === 'presetInstance') {
        var sel = seq.getSelection();
        if (!sel || sel.length === 0) return "Error: Select a clip in the timeline first to apply effects to.";
        var trackItem = sel[0];
        if (clip.effects && clip.effects.length > 0) {
            try {
                var mgt = trackItem.getMGTComponent();
                if (mgt && mgt.properties) {
                    for (var i = 0; i < clip.effects.length; i++) {
                        var eff = clip.effects[i];
                        if (eff.matchName) {
                            var prop = mgt.properties.findProperty(eff.matchName);
                            if (prop && eff.value !== undefined) {
                                prop.setValue(eff.value);
                            }
                        }
                    }
                }
            } catch (e) {
                return "Error applying effects: " + e.toString();
            }
            return "Success: Effects applied to selected clip";
        }
        return "Error: No effects saved in this preset";
    }

    // Full clip: import source and add to timeline
    var sourcePath = clip.source;
    if (!sourcePath) return "Error: No source path in clip data";

    var masterItem = ppFindItemByPath(project.rootItem, sourcePath);
    if (!masterItem) {
        var file = new File(sourcePath);
        if (!file.exists) return "Error: Source file not found: " + sourcePath;
        try {
            project.importFiles([sourcePath], true, project.rootItem, false);
            masterItem = ppFindItemByPath(project.rootItem, sourcePath);
        } catch (e) {
            return "Error importing: " + e.toString();
        }
    }
    if (!masterItem) return "Error: Could not find or import master item";

    try {
        var videoTracks = seq.videoTracks;
        if (videoTracks.numTracks === 0) return "Error: No video tracks in sequence";

        var track = videoTracks[0];
        var time = seq.getPlayerPosition();
        var newTrackItem = track.insertClip(masterItem, time);

        if (clip.clip && clip.clip.speed && clip.clip.speed !== 100) {
            try { newTrackItem.setSpeed(clip.clip.speed); } catch (e) {}
        }

        if (clip.effects && clip.effects.length > 0) {
            try {
                var mgt2 = newTrackItem.getMGTComponent();
                if (mgt2 && mgt2.properties) {
                    for (var j = 0; j < clip.effects.length; j++) {
                        var eff2 = clip.effects[j];
                        if (eff2.matchName) {
                            var prop2 = mgt2.properties.findProperty(eff2.matchName);
                            if (prop2 && eff2.value !== undefined) {
                                prop2.setValue(eff2.value);
                            }
                        }
                    }
                }
            } catch (e) {}
        }

        return "Success: Clip added to sequence";
    } catch (e) {
        return "Error adding clip: " + e.toString();
    }
}

// --- My Clips: After Effects apply clip/preset instance ---
function aeApplyClipInstance(jsonPath) {
    var f = new File(jsonPath);
    if (!f.exists) return "Error: Clip file not found";
    f.open('r');
    var content = f.read();
    f.close();
    var clip = JSON.parse(content);

    var project = app.project;
    if (!project) return "Error: No project open";
    var comp = project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return "Error: No active composition. Open a comp first.";

    // Preset-only: apply effects to selected layer, no file import
    if (clip.saveType === 'presetInstance') {
        var selLayers = comp.selectedLayers;
        if (!selLayers || selLayers.length === 0) return "Error: Select a layer first to apply effects to.";
        var targetLayer = selLayers[0];
        if (clip.effects && clip.effects.length > 0) {
            try {
                app.beginUndoGroup("Apply Effects Preset");
                for (var i = 0; i < clip.effects.length; i++) {
                    var eff = clip.effects[i];
                    try {
                        var newEff = targetLayer.Effects.addProperty(eff.matchName);
                        if (newEff && eff.params) {
                            for (var key in eff.params) {
                                if (eff.params.hasOwnProperty(key)) {
                                    var p = newEff.property(key);
                                    if (p) p.setValue(eff.params[key]);
                                }
                            }
                        }
                    } catch (e2) {}
                }
                app.endUndoGroup();
            } catch (e) {
                return "Error applying effects: " + e.toString();
            }
            return "Success: Effects applied to selected layer";
        }
        return "Error: No effects saved in this preset";
    }

    // Full clip: import source and add to comp
    var sourcePath = clip.source;
    if (!sourcePath) return "Error: No source path in clip data";

    var footage = aeFindItemByPath(project.rootFolder, sourcePath);
    if (!footage) {
        var file = new File(sourcePath);
        if (!file.exists) return "Error: Source file not found: " + sourcePath;
        try {
            var importOpts = new ImportOptions(file);
            footage = app.project.importFile(importOpts);
        } catch (e) {
            return "Error importing: " + e.toString();
        }
    }
    if (!footage) return "Error: Could not find or import source footage";

    try {
        app.beginUndoGroup("Apply My Clip");
        var layer = comp.layers.add(footage);
        layer.startTime = comp.time;

        if (clip.transform) {
            try {
                if (clip.transform.scale) layer.transform.scale.setValue(clip.transform.scale);
                if (clip.transform.position) layer.transform.position.setValue(clip.transform.position);
                if (clip.transform.rotation !== undefined) layer.transform.rotation.setValue(clip.transform.rotation);
                if (clip.transform.opacity !== undefined) layer.transform.opacity.setValue(clip.transform.opacity);
            } catch (e) {}
        }

        if (clip.effects && clip.effects.length > 0) {
            for (var j = 0; j < clip.effects.length; j++) {
                var eff2 = clip.effects[j];
                try {
                    var newEff2 = layer.Effects.addProperty(eff2.matchName);
                    if (newEff2 && eff2.params) {
                        for (var key2 in eff2.params) {
                            if (eff2.params.hasOwnProperty(key2)) {
                                var p2 = newEff2.property(key2);
                                if (p2) p2.setValue(eff2.params[key2]);
                            }
                        }
                    }
                } catch (e3) {}
            }
        }

        layer.selected = true;
        app.endUndoGroup();
        return "Success: Layer added to composition";
    } catch (e) {
        return "Error adding layer: " + e.toString();
    }
}

// Helper: find project item by media path (Premiere)
function ppFindItemByBin(bin, targetPath) {
    var norm = targetPath.replace(/\\/g, '/').toLowerCase();
    for (var i = 0; i < bin.children.numItems; i++) {
        var child = bin.children[i];
        if (child.type === ProjectItemType.BIN) {
            var found = ppFindItemByBin(child, targetPath);
            if (found) return found;
        } else {
            try {
                var mp = child.getMediaPath();
                if (mp && mp.replace(/\\/g, '/').toLowerCase() === norm) return child;
            } catch (e) {}
        }
    }
    return null;
}
function ppFindItemByPath(root, targetPath) {
    return ppFindItemByBin(root, targetPath);
}

// Helper: find footage item by path (AE)
function aeFindItemByFolder(folder, targetPath) {
    var norm = targetPath.replace(/\\/g, '/').toLowerCase();
    for (var i = 1; i <= folder.numItems; i++) {
        var item = folder.item(i);
        if (item instanceof FolderItem) {
            var found = aeFindItemByFolder(item, targetPath);
            if (found) return found;
        } else if (item instanceof FootageItem && item.file) {
            if (item.file.fsName.replace(/\\/g, '/').toLowerCase() === norm) return item;
        }
    }
    return null;
}
function aeFindItemByPath(rootFolder, targetPath) {
    return aeFindItemByFolder(rootFolder, targetPath);
}

$._ext = {
    // A simple function to test if the connection works
    ping: function() {
        return "pong";
    },

    importFile: function(filePath) {
        var file = new File(filePath);
        if (!file.exists) return "Error: File not found at " + filePath;

        var folderName = getLibraryFolderName(filePath);

        // After Effects Logic
        if (isAfterEffects()) {
            try {
                app.beginUndoGroup("Import Media");
                var importOptions = new ImportOptions(file);
                var item = app.project.importFile(importOptions);

                if (folderName) {
                    var folder = aeGetOrCreateFolder(app.project, folderName);
                    item.parentFolder = folder;
                }

                // Add to active comp if available, at the playhead position
                // rather than the comp's start (layers.add() always starts
                // a new layer at time 0 otherwise).
                var activeComp = app.project.activeItem;
                if (activeComp && activeComp instanceof CompItem) {
                    // layers.add() always inserts at the very top of the
                    // stack. If a layer is selected, stack the new one
                    // directly above it instead - the topmost one, if
                    // several are selected. With nothing selected, the
                    // default top-of-stack placement is left as-is.
                    var priorSelection = activeComp.selectedLayers;
                    var referenceLayer = null;
                    if (priorSelection && priorSelection.length > 0) {
                        referenceLayer = priorSelection[0];
                        for (var ps = 1; ps < priorSelection.length; ps++) {
                            if (priorSelection[ps].index < referenceLayer.index) referenceLayer = priorSelection[ps];
                        }
                    }

                    var layer = activeComp.layers.add(item);
                    layer.startTime = activeComp.time;

                    if (referenceLayer) {
                        try { layer.moveBefore(referenceLayer); } catch (e) {}
                        for (var ds = 0; ds < priorSelection.length; ds++) {
                            try { priorSelection[ds].selected = false; } catch (e) {}
                        }
                    }

                    layer.selected = true; // Select the new layer so the user sees it
                }
                app.endUndoGroup();
                return "Success";
            } catch(e) {
                return "AE Error: " + e.toString();
            }
        }
        // Premiere Pro Logic
        else {
            try {
                var project = app.project;
                var targetBin = folderName ? ppGetOrCreateBin(project.rootItem, folderName) : project.getInsertionBin();
                var paths = [filePath];
                project.importFiles(paths, true, targetBin, false);
                return "Success";
            } catch(e) {
                return "Premiere Error: " + e.toString();
            }
        }
    },

    // Called after a native drag-and-drop into the Project panel / timeline has
    // already imported the file. Finds the resulting item and files it into
    // the correct library bin/folder.
    organizeDroppedFile: function(filePath) {
        try {
            var folderName = getLibraryFolderName(filePath);
            if (!folderName) return "Skipped: unrecognized type";

            var isAE = isAfterEffects();

            if (isAE) {
                var project = app.project;
                var target = null;
                for (var i = 1; i <= project.numItems; i++) {
                    var it = project.item(i);
                    if (it instanceof FootageItem && it.mainSource && it.mainSource.file &&
                        it.mainSource.file.fsName === filePath) {
                        target = it;
                        break;
                    }
                }
                if (!target) return "NotFound";
                var folder = aeGetOrCreateFolder(project, folderName);
                target.parentFolder = folder;
                return "Success";
            } else {
                var pproject = app.project;
                var item = ppFindItemByPath(pproject.rootItem, filePath);
                if (!item) return "NotFound";
                var bin = ppGetOrCreateBin(pproject.rootItem, folderName);
                item.moveBin(bin);
                return "Success";
            }
        } catch(e) {
            return "Error (line " + e.line + "): " + e.toString();
        }
    },

    // Scans the whole project and files loose items into library bins.
    // Premiere: Video Library, SFX Library, Music Library, Images Library,
    // Solids, Sequences, Nests, Motion Graphics Templates, Linked Comps,
    // Subtitles, Offline, and Unused. Video/audio/image items already filed
    // into a bin the user named themselves (not one of our own managed
    // folder names) are left alone; items sitting in one of our own managed
    // folders - even nested, e.g. from a prior per-sequence run - are
    // re-examined and re-filed as needed. Offline always pulls offline items
    // out no matter where they are (their original bin is remembered so
    // Restore Offline Files can put them back).
    // After Effects: same idea, but Comps/Nested Comps instead of
    // Sequences/Nests, genuine Solid footage items, and no Motion Graphics
    // Templates/Linked Comps/Offline-restore support yet (those aren't
    // meaningful AE project-panel concepts, or are a planned follow-up).
    organizeProject: function() {
        try {
            if (isAfterEffects()) {
                var aeResult = null;
                app.beginUndoGroup("Organize Project");
                try {
                    aeResult = aeOrganizeProjectImpl();
                } finally {
                    app.endUndoGroup();
                }
                return aeResult;
            }
            var project = app.project;
            if (typeof project.executeTransaction === 'function') {
                var resultHolder = { value: null };
                project.executeTransaction(function() {
                    resultHolder.value = organizeProjectImpl();
                }, "Organize Project");
                return resultHolder.value;
            } else {
                return organizeProjectImpl();
            }
        } catch(e) {
            return "Error (line " + e.line + "): " + e.toString();
        }
    },

    // Alternate to organizeProject: gives each top-level sequence/comp its
    // own folder (with the same library sub-structure) for files it uses
    // exclusively; files used by 2+ sequences/comps go into "Shared Files"
    // instead of being duplicated. Unlike organizeProject, this touches
    // every file regardless of current location, since it's regrouping by
    // a different axis (which sequence/comp uses it) than any prior manual
    // sort. Premiere: Sequences/Nests. AE: Comps/Nested Comps.
    organizeProjectBySequence: function() {
        try {
            if (isAfterEffects()) {
                var aeResult = null;
                app.beginUndoGroup("Organize Project By Comp");
                try {
                    aeResult = aeOrganizeProjectByCompImpl();
                } finally {
                    app.endUndoGroup();
                }
                return aeResult;
            }
            var project = app.project;
            if (typeof project.executeTransaction === 'function') {
                var resultHolder = { value: null };
                project.executeTransaction(function() {
                    resultHolder.value = organizeProjectBySequenceImpl();
                }, "Organize Project By Sequence");
                return resultHolder.value;
            } else {
                return organizeProjectBySequenceImpl();
            }
        } catch(e) {
            return "Error (line " + e.line + "): " + e.toString();
        }
    },

    // Looks at everything in the Offline bin/folder; anything that's no
    // longer offline (i.e. relinked) gets moved back to where it came from,
    // recreating that path if needed. Items with no recorded origin (e.g.
    // placed in Offline before this feature existed) are left alone.
    restoreOfflineFiles: function() {
        try {
            if (isAfterEffects()) {
                var aeResult = null;
                app.beginUndoGroup("Restore Offline Files");
                try {
                    aeResult = aeRestoreOfflineFilesImpl();
                } finally {
                    app.endUndoGroup();
                }
                return aeResult;
            }
            var project = app.project;
            if (typeof project.executeTransaction === 'function') {
                var resultHolder = { value: null };
                project.executeTransaction(function() {
                    resultHolder.value = restoreOfflineFilesImpl();
                }, "Restore Offline Files");
                return resultHolder.value;
            } else {
                return restoreOfflineFilesImpl();
            }
        } catch(e) {
            return "Error (line " + e.line + "): " + e.toString();
        }
    },

    // --- My Clips: Save selected clip/layer with effects ---
    saveSelectedClip: function() {
        try {
            if (isAfterEffects()) {
                return aeSaveSelectedClip();
            }
            return ppSaveSelectedClip();
        } catch(e) {
            return "Error (line " + e.line + "): " + e.toString();
        }
    },

    // --- My Clips: Apply saved clip instance to active sequence ---
    applyClipInstance: function(jsonPath) {
        try {
            if (isAfterEffects()) {
                return aeApplyClipInstance(jsonPath);
            }
            return ppApplyClipInstance(jsonPath);
        } catch(e) {
            return "Error (line " + e.line + "): " + e.toString();
        }
    }
};
