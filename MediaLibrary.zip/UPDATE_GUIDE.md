# Media Library — Update System Guidebook
*Copy this to any Premiere / After Effects CEP plugin in 15 minutes.*

---

## 1) How It Works (30 sec)

**You publish:** Edit visually → Save & Publish → `update.json` + media bundled **inside the zip** (no server) → pushed to a tiny **public** GitHub repo → Release `MediaLibrary.zip` attached.

**User gets:** Panel fetches `update.json` from `raw.githubusercontent.com` on launch (with `?t=Date.now()` to bust cache) → banner `Version 1.0.x available!` → **Install Now** downloads zip → extracts **over the live extension folder** → reloads → **Adobe-style What's New** carousel (images/videos + buttons) shows once.

**No server needed** — images/videos are inside the zip, loaded via `file://` after update. Buttons link anywhere via `cep.util.openURLInDefaultBrowser`.

**Private code stays private:** Your main repo stays **private**, the tiny `-releases` public repo only holds `update.json` + zip (no browsable source). `publish.ps1` pushes to both.

---

## 2) Files You Need

Copy these from this project:

| File | Purpose |
|------|---------|
| `js/main.js` → helpers `compareVersions`, `httpGet`, `fetchUpdateManifest`, `applyHotUpdate`, `resolveWhatsNewMedia`, `showWhatsNewCarousel`, `showWhatsNewIfPending`, `loadLocalUpdateJson`, version indicator + welcome | Update logic + UI |
| `css/style.css` → `#update-banner`, `#whatsnew-overlay`, `.whatsnew-box`, `.sidebar-footer`, `#welcome-overlay` | Styling |
| `index.html` → `#update-banner`, `#whatsnew-overlay`, `#welcome-overlay`, `.sidebar-footer` (version, What's New, About, Support button) | Markup |
| `update.json` | Manifest (see template below) |
| `publisher.html` + `publisher-server.js` + `publisher.cmd` | Visual editor (no cmd typing) — edit pages with images/videos + buttons, live preview |
| `publish.ps1` + `publish.cmd` | One-click push (handles private + public repos, zips, tags, Release) |
| `whatsnew/` folder | Media bundled in zip, loaded via `file://` |
| `LICENSE` | `All Rights Reserved` — strangers can see zip but can't reuse |

---

## 3) update.json Template

```json
{
  "version": "1.0.0",
  "type": "hot",
  "message": "Version 1.0.0 available!",
  "whatsNew": {
    "title": "What's New in v1.0.0",
    "pages": [
      {
        "title": "Interactive tutorials",
        "description": "Browse tutorials for every level.",
        "media": "whatsnew/1.0.0/page1.jpg",
        "mediaType": "image",
        "buttons": [
          { "label": "Learn more", "url": "https://example.com", "primary": true },
          { "label": "View tutorials", "url": "https://example.com" }
        ]
      }
    ]
  },
  "about": {
    "portfolioUrl": "https://abdulrezak.com",
    "welcomeText": "Welcome text shown on first launch."
  },
  "notes": ["Fallback plain bullets if carousel missing"],
  "zipUrl": "https://github.com/YOU/YOUR-REPO-releases/releases/latest/download/MediaLibrary.zip",
  "zxpUrl": "https://github.com/YOU/YOUR-REPO-releases/releases/latest/download/MediaLibrary.zxp"
}
```

`notes` is kept for back-compat — old versions show it as single page.

---

## 4) js/main.js — Key Pieces to Copy

**1. Top constants:**
```js
const CURRENT_VERSION = '1.0.0';
let PORTFOLIO_URL = 'https://abdulrezak.com';
const UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/YOU/YOUR-REPO-releases/main/update.json';
```

**2. Helpers (copy verbatim):**
- `compareVersions(a,b)` — numeric `1.10.0 > 1.9.0`
- `httpGet(url,cb)` — with redirect follow for GitHub 302s
- `fetchUpdateManifest()` — adds `?t=Date.now()` to bust CDN cache, strips BOM, `JSON.parse`
- `resolveWhatsNewMedia(p)` — `http` stays URL, else `file:/// + extensionPath + p`
- `applyHotUpdate(zipUrl)` — download to temp, `Expand-Archive` via PowerShell, copy over `getSystemPath('extension')`, reload
- `loadLocalUpdateJson()` — tries `extension/update.json`, relative paths, `cep.fs`, and `lastUpdateInfo` fallback — handles BOM
- `showWhatsNewCarousel(pages, version)` — builds left nav + media (image/video) + buttons + dots + Next/Previous/Done, opens links via `cep.util.openURLInDefaultBrowser`

**3. Startup flow in `DOMContentLoaded`:**
```js
// Version badge + double-click to open DevTools (Ctrl+Shift+J doesn't work in CEP)
versionIndicator.textContent = 'v' + CURRENT_VERSION;
versionIndicator.addEventListener('dblclick', () => window.__adobe_cep__.showDevTools());

// Welcome (once)
if (!localStorage.getItem('hasSeenWelcome')) setTimeout(showWelcome, 800);

// Update banner
fetchUpdateManifest().then(info => {
  lastUpdateInfo = info;
  if (info.about) { if (info.about.portfolioUrl) PORTFOLIO_URL = info.about.portfolioUrl; /* update welcome text */ }
  if (compareVersions(CURRENT_VERSION, info.version) >= 0) return;
  updateBanner.classList.remove('hidden');
  const pendingPayload = JSON.stringify({ version: info.version, whatsNew: info.whatsNew, notes: info.notes });
  updateActionBtn.onclick = async () => {
    await applyHotUpdate(info.zipUrl);
    localStorage.setItem('whatsNew', pendingPayload);
    location.reload();
  };
});

// Manual What's New button
whatsNewBtn.addEventListener('click', showWhatsNewManually); // tries localStorage → local file → network
```

**4. `showWhatsNewManually()` — 3-tier:** `localStorage` → `loadLocalUpdateJson()` (offline) → `fetchUpdateManifest()` (online). Never shows `Check internet` if local file exists.

---

## 5) GitHub Setup (once, 2 min)

1. Create **private** repo `YOUR/PLUGIN` (no README).
2. First `publisher.cmd` run asks for `privateRepo` and `publicRepo` (e.g. `YOUR/PLUGIN` and `YOUR/PLUGIN-releases`) — it creates the public repo automatically and patches `UPDATE_MANIFEST_URL` + `PORTFOLIO_URL`.
3. Install `gh` CLI → `gh auth login` (HTTPS → Yes → Browser) → `gh auth setup-git` (so `git push` doesn't hang).
4. Done — private holds code, public holds only `update.json` + zip.

---

## 6) Publishing (30 sec, visual)

**Visual (recommended):** Double-click `publisher.cmd` → `http://localhost:3415` → set **Version** + **Banner message** + **Portfolio URL** + **Welcome text** → `+ Add Page` per feature → drop **image/video** (bundled in `whatsnew/<ver>/`, no server) → add **Buttons** (label + URL + Primary) → live preview on right → **Save & Publish →** → auto pushes + creates Release → users see banner + tour.

**Fallback (cmd):** `publish.cmd` → type version → type bullets (or skip if `whatsNew` already in `update.json`) → pushes.

**What gets zipped:** Everything **except** `node_modules/.git/.claude/publisher.*` — plus `whatsnew/` is re-added so media is inside zip. `update.json`'s `whatsNew.pages[].media` is `whatsnew/<ver>/file.jpg` → resolved to `file://` after extract.

---

## 7) To Add This to Another Plugin

1. Copy the files listed in (2) into the new plugin.
2. Change `UPDATE_MANIFEST_URL` + `PORTFOLIO_URL` + `ExtensionBundleId` in manifest.
3. Create its `-releases` public repo (or reuse same one with different asset name).
4. Open `publisher.html`, set portfolio, create pages, **Save & Publish**.
5. Test: Install old zip, launch panel → banner → Install → tour appears. Use footer **What's New** to replay anytime, **About** for welcome, double-click version for DevTools.

---

## 8) Gotchas

- **BOM:** `update.json` saved as UTF-8-BOM breaks `JSON.parse` — always `.replace(/^\uFEFF/,'')` + `.trim()` before parse (both in `fetch` and `loadLocal`).
- **CDN cache:** `raw.githubusercontent.com` caches 5 min — always append `?t=Date.now()`.
- **Private repo:** Don't point `UPDATE_MANIFEST_URL` to private — use the public `-releases` one.
- **`gh` PATH:** Add `;C:\Program Files\GitHub CLI` to `PATH` in `publish.ps1` or `gh` not found when run via Node.
- **`publish.ps1` pause:** Use `-NoPause` when called from `publisher-server.js` or it hangs waiting for Enter.
- **Tag exists:** `git push --tags` will warn `already exists` for old tags — harmless, new tag still pushes.

---

## 9) Checklist for New Plugin

- [ ] Copied helpers + CSS + HTML
- [ ] Set `CURRENT_VERSION`, `PORTFOLIO_URL`, `UPDATE_MANIFEST_URL`
- [ ] Created private + public repos, `gh auth login` + `setup-git`
- [ ] Tested publisher preview — image/video shows, buttons open links
- [ ] Published `1.0.0` → installed on test machine with `1.0.0` → saw banner → installed → saw tour → `What's New` replays offline

You now have the same future — no server, visual editing, offline support, private code.
